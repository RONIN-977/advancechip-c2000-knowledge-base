# FIXED

UserCode/Com/Src/ring_queue.obj: ../UserCode/Com/Src/ring_queue.c
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/UserCode/Com/Inc/ring_queue.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Device.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Adc.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_BootVars.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Cla.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Comp.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_CpuTimers.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_DevEmu.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Dma.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_ECan.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_ECap.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_EPwm.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_EQep.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Gpio.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_HRCap.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_I2c.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Mcbsp.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_NmiIntrupt.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_PieCtrl.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_PieVect.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Spi.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Sci.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_SysCtrl.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Usb.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_XIntrupt.h

../UserCode/Com/Src/ring_queue.c: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/UserCode/Com/Inc/ring_queue.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Device.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Adc.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_BootVars.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Cla.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Comp.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_CpuTimers.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_DevEmu.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Dma.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_ECan.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_ECap.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_EPwm.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_EQep.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Gpio.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_HRCap.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_I2c.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Mcbsp.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_NmiIntrupt.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_PieCtrl.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_PieVect.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Spi.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Sci.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_SysCtrl.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_Usb.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_BOOT_CAN/Library/Per_Inc/AVP32F069_XIntrupt.h: 

#ifndef UPGRADE_ENTRY_H
#define UPGRADE_ENTRY_H
/* Call init once after Device_init. Call poll frequently (<1 ms preferred).
 * In an existing application, adapt this to that application's own CAN
 * receive dispatcher instead of configuring the peripheral a second time.
 * Quiesce PWM/relays/control outputs BEFORE accepting an upgrade request. */
/* [K08] 客户设备初始化、boot_can_objects_init 后调用一次；只初始化协议状态。 */
void upgrade_entry_init(void);
/* [移植必需] 后台主循环频繁调用，优选间隔 <1 ms；不在控制 ISR 中调用。 */
void upgrade_entry_poll(void);
#endif

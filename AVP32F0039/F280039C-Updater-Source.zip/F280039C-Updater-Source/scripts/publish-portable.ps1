$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$env:DOTNET_CLI_HOME = Join-Path $root '.dotnet'
$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
$output = Join-Path $root 'build\portable\F280039C-Updater'
& dotnet publish "$root\host\Updater.Desktop\Updater.Desktop.csproj" -c Release -r win-x64 --self-contained true --source https://api.nuget.org/v3/index.json -o $output
if ($LASTEXITCODE -ne 0) { throw 'Desktop publish failed' }
& dotnet publish "$root\host\CanBridge32\CanBridge32.csproj" -c Release -r win-x86 --self-contained true --source https://api.nuget.org/v3/index.json -o "$output\bridge\x86"
if ($LASTEXITCODE -ne 0) { throw 'Bridge publish failed' }
Get-ChildItem -LiteralPath "$root\assets" | Copy-Item -Destination $output -Recurse -Force
New-Item -ItemType Directory -Path "$output\firmware" -Force | Out-Null
Copy-Item -LiteralPath "$root\build\firmware\application.out" -Destination "$output\firmware" -Force
Copy-Item -LiteralPath "$root\docs\portable-readme.md" -Destination "$output\使用说明.md" -Force
Compress-Archive -LiteralPath $output -DestinationPath "$root\build\portable\F280039C-Updater-Portable-win-x64.zip" -Force
Write-Output "Portable application: $output"



#include "MotorInclude.h"
#include "param_lr.h"

int gSendToFunctionDataBuff[MOTOR_TO_FUNCTION_DATA_NUM];
Uint gSendToMotorDataBuff[FUNCTION_TO_MOTOR_DATA_NUM];				//���ݸ�����ģ�������

INV_STRUCT 				gInvInfo;		//��Ƶ����Ϣ
MOTOR_STRUCT 			gMotorInfo;		//�����Ϣ

RUN_STATUS_STRUCT 		gMainStatus;	//������״̬
BASE_COMMAND_STRUCT		gMainCmd;		//������

/************************************************************/
/**********����Ϊ�͵����������趨��������******************/
BASE_PAR_STRUCT			gBasePar;		//�������в���

ADC_STRUCT				gADC;			//ADC���ݲɼ��ṹ
UDC_STRUCT				gUDC;			//ĸ�ߵ�ѹ����
IUVW_SAMPLING_STRUCT	gCurSamp;
UVW_STRUCT				gIUVW;			//�����������������
ALPHABETA_STRUCT		gIAlphBeta;		//�����������������
MT_STRUCT				gIMT;			//MT��ϵ�µĵ���
AMPTHETA_STRUCT			gIAmpTheta;		//�������ʾ�ĵ���
LINE_CURRENT_STRUCT		gLineCur;	
ANGLE_STRUCT			gPhase;			//�ǶȽṹ
JUDGE_POWER_LOW			gLowPower;		//�ϵ绺���ж�ʹ�����ݽṹ
JUDGE_ACC_DEC_STRUCT	gSpeedFlag;		//�жϼӼ��ٱ�־�Ľṹ
CUR_EXCURSION_STRUCT	gExcursionInfo;	//�����Ưʹ�õĽṹ
DEAD_BAND_STRUCT		gDeadBand;

CBC_PROTECT_STRUCT      gCBCProtect;
TEMPLETURE_STRUCT		gTemperature;
PHASE_LOSE_STRUCT		gPhaseLose;
	
FC_CAL_STRUCT			gFcCal;
OVER_UDC_CTL_STRUCT		gOvUdc;
DC_BRAKE_STRUCT         gDCBrake;
OUT_VOLT_STRUCT			gOutVolt;
Uint					gRatio;			//����ϵ��
PWM_OUT_STRUCT			gPWM;

SYN_PWM_STRUCT			gSynPWM;
FEISU_STRUCT			gFeisu;			//ת�ٸ����ñ���
CPU_TIME_STRUCT			gDSPActiveTime;

PM_INIT_POSITION        gIPMInitPos;
PM_FLUX_WEAK		    gFluxWeak;

Uint const m_pTable_y[23] = {
    26,     // 12Degree---
    33,     // 16Degree---
    39,     // 20Degree---VTS=0.5V, 0.5*4096 / 3.3 = 620. 620 >> 4 = 39
    45,     // 24Degree---
    51,
    57,
    64,
    70,
    76,
    82,
    88,
    95,
    101,
    107,
    113,
    119,
    126,
    132,    // 80Degree -- VTS = 1.7V, 1,7 * 4096 / 3.3 / 16 = 132
    138,
    144,
    150,
    157,
    165     // 100Degree---VTS=2.13V, 2.13*4096 / 3.3 / 16= 165
};
Uint const m_pTable_x[23] = {
    12,
    16,
    20,
    24,
    28,
    32,
    36,
    40,
    44,
    48,
    52,
    56,
    60,
    64,
    68,
    72,
    76,
    80,
    84,
    88,
    92,
    96,
    100
};
//---------------------------------------------------------------
//�������ģ��Ϳ���ģ��Ľ�����
//---------------------------------------------------------------
Uint MotorPWMRandom;
Uint MotorSpeedScaling2ONKB10;

Uint DCBrakeCur;
Uint TorqueCurrentLimit;
Uint OverspeedScaling;
Uint SpeedFeedbackFilter;
Uint SFLowSpeed;
Uint MinCurrentLowSpeed;
Uint SpecailFactor;
Uint SpeedMeasureFactor1;
Uint SpeedMeasureFactor2;
Uint StartPresetCurrent;
Uint LowLimitFrequency;
Uint FieldWeakMode;
Uint FieldWeakCurScale;
Uint FieldWeakScale;
Uint FieldWeakRef;
Uint DataRsrd;
Uint IPDCurrentScaling;
Uint IPDAutoDectScaling;

Uint IdMaxSet;
Uint IqFWLimit;
Uint FiveSegModeEn;

Uint AVREnableMode;
Uint MotorTestData1;
Uint MotorTestData2;
Uint MotorTestData3;
Uint NoNegativeOMG;
Uint MotorTestData4;
Uint MotorTestData5;
Uint NewOBS;
Uint QPR_EN;
long SpeedUsed;

unsigned long   l_ld;
unsigned long   l_lq;

Uint * const gSendToMotorTable[FUNCTION_TO_MOTOR_DATA_NUM] = 
{
	(Uint *)&gMainCmd.Command.all,	(Uint *)&gMainCmd.FreqSet,			//0��1
	(Uint *)&gMainCmd.VCTorqueLim,	&DataRsrd,		                    //2��3
	&gBasePar.FcSet,				&gBasePar.UpFreq,					//4��5
	&DataRsrd,													        //6
	&gBasePar.MaxFreq,				&DataRsrd,					        //7��8
	&DataRsrd,													        //9
	&DataRsrd,                      							        //10
	&gMotorInfo.Votage,				&gMotorInfo.CurrentGet,				//11��12
	&gMotorInfo.Frequency,												//13
	&IdMaxSet,                      (Uint *)&cof_uwMaxThetaPerCntTcPu,  //14��15
	&gInvInfo.InvUpUDCCoef,			&gInvInfo.InvLowUDCCoef,			//16��17
	&DataRsrd,		                &DataRsrd,                          //18��19
	&DataRsrd,				        &DataRsrd,                          //20��21
	&MotorPWMRandom, 	    		&IqFWLimit,			                //22��23
	&DataRsrd,                         							        //24
	&DCBrakeCur,                     				                    //25

    &TorqueCurrentLimit,
    &OverspeedScaling,
    &SpeedFeedbackFilter,
    &SFLowSpeed,
    &MinCurrentLowSpeed,
    &SpecailFactor,
    &SpeedMeasureFactor1,
    &SpeedMeasureFactor2,
    &StartPresetCurrent,
    &LowLimitFrequency,
    &FieldWeakMode,
    &FieldWeakCurScale,
    &FieldWeakScale,
    &FieldWeakRef,
    &IPDCurrentScaling,
    &IPDAutoDectScaling,

    &AVREnableMode,
    &MotorTestData1,
    (Uint *)&cof_uwMaxThetaPerCntTcPu,
    &NoNegativeOMG,
    &MotorTestData4,
    &MotorTestData5,
}; 
 
Uint gSoftVersion = SOFT_VERSION;
Uint * const gSendToFuncTable[MOTOR_TO_FUNCTION_DATA_NUM] = 
{
	&gMainStatus.StatusWord.all,	&gMainStatus.ErrorCode,				//0��1
	(Uint *)&gLineCur.ErrorShow,	(Uint *)&gMainCmd.FreqPreWs,				//2��3
	(Uint *)&gUDC.uDCFilter,		(Uint *)&gLineCur.CurPer,			//4��5
	(Uint *)&gOutVolt.VoltApply,	&gTemperature.Temp,					//6��7
	(Uint *)&gSoftVersion,			(Uint *)&gSoftVersion,				//8��9
	(Uint *)&pm_omg_show,			&gInvInfo.InvCurrent
};

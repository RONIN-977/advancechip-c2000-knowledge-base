/****************************************************************
�ļ����ܣ�
�ļ��汾��
���¸��£�
****************************************************************/
MEMORY
{
PAGE 0:    /* Program Memory */
           /* Memory (RAM/FLASH/OTP) blocks can be moved to PAGE1 for data allocation */
           /*ADP32F036_027_Flash_API_ZONE.lib ���������¶���
           *      ����					��ַ					����			��ע
           *  ����H (8K x 16)     0x3E8000 - 0x3E9FFF       0x2000
           *  ����G (8K x 16)     0x3EA000 - 0x3EBFFF       0x2000
           *  ����F (8K x 16)     0x3EC000 - 0x3EDFFF       0x2000
           *  ����E (8K x 16)     0x3EE000 - 0x3EFFFF       0x2000
           *  ����D (8K x 16)     0x3F0000 - 0x3F1FFF       0x2000		App
           *  ����C (15K x 16)    0x3F2000 - 0x3F57FF       0x3800
           *  ����B (1K x 16)     0x3F5800 - 0x3F5FFF       0x0800		EERPOM
  		   *  ����A (8K x 16)     0x3F6000 - 0x3F7FFF       0x2000 		BOOT
           */
   /*�û��Զ��������ڴ���䣬����boot��App*/
   BEGIN       : origin = 0x3F7FF6, length = 0x000002     /* Part of FLASHA.  Used for "boot to Flash" bootloader mode. */
   /*Boot*/
   FLASHA	   : origin = 0x3F6000, length = 0x001F80     /* on-chip FLASA for Boot */
   /*Eeprom*/
   FLASHB	   : origin = 0x3F5C00, length = 0x000400     /* on-chip FLASB for EEPROM */

   /*App*/
   FLASHH	   : origin = 0x3E8000, length = 0x00C000     /* on-chip FLASG for App */

   /*************************/
   /*���¶�Ӧ036ϵ�й̶��ڴ棬��ֹ�Ķ�*/
   CSM_RSVD    : origin = 0x3F7F80, length = 0x000076     /* Part of FLASHA.  Program with all 0x0000 when CSM is in use. */
   CSM_PWL     : origin = 0x3F7FF8, length = 0x000008     /* Part of FLASHA.  CSM password locations in FLASHA */
   RAMPRG      : origin = 0x008000, length = 0x000C00     /* on-chip RAM block L0, for RamFuncs */
   OTP         : origin = 0x3D7800, length = 0x000400     /* on-chip OTP */
   IQTABLES    : origin = 0x3FE000, length = 0x000B50     /* IQ Math Tables in Boot ROM */
   IQTABLES2   : origin = 0x3FEB50, length = 0x00008C     /* IQ Math Tables in Boot ROM */
   IQTABLES3   : origin = 0x3FEBDC, length = 0x0000AA	  /* IQ Math Tables in Boot ROM */
   ROM         : origin = 0x3FF27C, length = 0x000D44     /* Boot ROM */
   RESET       : origin = 0x3FFFC0, length = 0x000002     /* part of boot ROM  */
   VECTORS     : origin = 0x3FFFC2, length = 0x00003E     /* part of boot ROM  */

PAGE 1 :   /* Data Memory */
           /* Memory (RAM/FLASH/OTP) blocks can be moved to PAGE0 for program allocation */
           /* Registers remain on PAGE1                                                  */

   RAMM0       : origin = 0x000100, length = 0x000300     /* on-chip RAM block M0 */
   RAMM1       : origin = 0x000400, length = 0x000400     /* on-chip RAM block M1 */
   RAML0       : origin = 0x008C00, length = 0x001400     /* on-chip RAM block L0 */
   RAMH0	   : origin = 0x00A000, length = 0x002000     /* on-chip RAM block H0 */
/*   RAML1	   : origin = 0x009000, length = 0x001000*/	  /* on-chip RAM block L1 */
}

/* Allocate sections to memory blocks.
   Note:
         codestart user defined section in DSP28_CodeStartBranch.asm used to redirect code 
                   execution when booting to flash
         ramfuncs  user defined section to store functions that will be copied from Flash into RAM
*/ 
 
SECTIONS
{
 
   /* Allocate program areas: */
   .cinit              : > FLASHH      PAGE = 0
   .pinit              : > FLASHH,     PAGE = 0
   .text               : > FLASHH      PAGE = 0
   .binit              : > FLASHH,     PAGE = 0
   .ovly			   : > FLASHH,     PAGE = 0
   codestart           : > BEGIN       PAGE = 0
   ramfuncs            :
   {
		/*-lADP32F036_027_Flash_API.lib(.econst)
		-lADP32F036_027_Flash_API.lib(.text)*/
		-lADP32F036_027_Flash_API_ZONE.lib(.econst)
		-lADP32F036_027_Flash_API_ZONE.lib(.text)

   }					 LOAD = FLASHH,
                         RUN = RAMPRG, 
                         PAGE = 0,
						 table(_prginRAM)

   otp_prg			   : > OTP         PAGE = 0
   csmpasswds          : > CSM_PWL     PAGE = 0
   csm_rsvd            : > CSM_RSVD    PAGE = 0
   
   /* Allocate uninitalized data sections: */
   .stack              : > RAMM1       PAGE = 1
   .ebss               : > RAML0 | RAMH0       PAGE = 1
   .esysmem            : > RAML0       PAGE = 1
   debug_buffer		   : > RAML0       PAGE = 1

   /* Initalized sections go in Flash */
   /* For SDFlash to program these, they must be allocated to page 0 */
   .econst             : > FLASHH      PAGE = 0
   .switch             : > FLASHH      PAGE = 0

   /* Allocate IQ math areas: */
   IQmath              : > FLASHH      PAGE = 0                  /* Math Code */
   IQmathTables        : > IQTABLES,   PAGE = 0, TYPE = NOLOAD

  /* Uncomment the section below if calling the IQNexp() or IQexp()
      functions from the IQMath.lib library in order to utilize the
      relevant IQ Math table in Boot ROM (This saves space and Boot ROM
      is 1 wait-state). If this section is not uncommented, IQmathTables2
      will be loaded into other memory (SARAM, Flash, etc.) and will take
      up space, but 0 wait-state is possible.
   */
   /*
   IQmathTables2    : > IQTABLES2, PAGE = 0, TYPE = NOLOAD
   {

              IQmath.lib<IQNexpTable.obj> (IQmathTablesRam)

   }
   */
    /* Uncomment the section below if calling the IQNasin() or IQasin()
       functions from the IQMath.lib library in order to utilize the
       relevant IQ Math table in Boot ROM (This saves space and Boot ROM
       is 1 wait-state). If this section is not uncommented, IQmathTables2
       will be loaded into other memory (SARAM, Flash, etc.) and will take
       up space, but 0 wait-state is possible.
    */
    /*
    IQmathTables3    : > IQTABLES3, PAGE = 0, TYPE = NOLOAD
    {

               IQmath.lib<IQNasinTable.obj> (IQmathTablesRam)

    }
    */

   /* .reset is a standard section used by the compiler.  It contains the */
   /* the address of the start of _c_int00 for C Code.   /*
   /* When using the boot ROM this section and the CPU vector */
   /* table is not needed.  Thus the default type is set here to  */
   /* DSECT  */
   .reset              : > RESET,      PAGE = 0, TYPE = DSECT
   vectors             : > VECTORS     PAGE = 0, TYPE = DSECT
}

/*
//===========================================================================
// End of file.
//===========================================================================
*/


# FIXED

Main/ADP32F03x_GlobalVariableDefs.obj: ../Main/ADP32F03x_GlobalVariableDefs.c
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
Main/ADP32F03x_GlobalVariableDefs.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h

../Main/ADP32F03x_GlobalVariableDefs.c:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:


/*
 * main.h
 *
 *  Created on: Feb 11, 2022
 *      Author: rand C
 */

#ifndef MAIN_H_
#define MAIN_H_

#include <02_control/01_resolver/Resolver.h>
#include <02_control/02_FVC/TaskScheduler.h>
#include <sysInit_28002x.h>
#include "user_math.h"
#include "uC_hal.h"
#include "LogicMethods.h"
#include "flash_hal.h"
#include "config.h"
#endif /* 01_SYSINIT_MAIN_H_ */

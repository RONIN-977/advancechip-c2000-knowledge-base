/******************************************************************************
�ļ���                      : speed_meas_hall.h
����                          : ������
��������                  : ת�ټ��㣨hall��ģ������
����ʱ��                  : 05-21-2019
�汾                          : V1.0
�޶�ʱ��                  :
�޶�����                  :
*******************************************************************************/

#ifndef SPEED_MEAS_HALL_H
#define SPEED_MEAS_HALL_H


#ifdef __cplusplus
extern "C" {
#endif


// �ٶȼ���(hall)��ؽṹ��
typedef struct {
    unsigned long HallState;           // Input:
    unsigned long PreHallState;        // Variable:
    unsigned long LoopCnt;             // Variable:
    unsigned long LoopCntRecord[6];    // Variable:
    unsigned long LoopCntIndex;        // Variable:
    unsigned long LoopCntSum;          // Variable:
    unsigned long PosCnt;              // Variable:
    unsigned long NegCnt;              // Variable:
    unsigned long MintSpeedCnt;        // Parameter:
    unsigned long K1;                  // Parameter:
    unsigned int RotateDir;            // Output: �����ת����0��ֹͣ��1����ת��2����ת
    unsigned long Speed;               // Output: ���ת�٣���Ƶ�ʣ�����λ��Hz
    unsigned long RealSpeed;               // Output: ���ת�٣���Ƶ�ʣ�����λ��0.001Hz
    void  (*calc)();                   // Pointer to calculation function
    } SPEED_HALL;                      // Data type created

typedef SPEED_HALL *SPEED_HALL_handle;

/*-----------------------------------------------------------------------------
Default initalizer for the SPEED_HALL object.
-----------------------------------------------------------------------------*/
#define SPEED_HALL_DEFAULTS   { 0, \
                                0, \
                                0, \
                                {0,0,0,0,0,0}, \
                                0, \
                                0, \
                                0, \
                                0, \
                                0, \
                                0, \
                                0, \
                                0, \
                                0, \
                                (void (*)(unsigned long))speed_hall_calc }

/*------------------------------------------------------------------------------
Prototypes for the functions in speed_meas_hall.c
------------------------------------------------------------------------------*/
void speed_hall_calc(SPEED_HALL_handle);
void speed_hall_calc_opt(SPEED_HALL_handle);


//---------------------------------------------------------------------------
// speed_meas_hall External References & Function Declarations:
//
extern volatile SPEED_HALL speedMeasHall;
extern volatile float MeasurableSpeedMin;


#ifdef __cplusplus
}
#endif /* extern "C" */


#endif  // end of SPEED_MEAS_HALL_H definition

//===========================================================================
// No more.
//===========================================================================

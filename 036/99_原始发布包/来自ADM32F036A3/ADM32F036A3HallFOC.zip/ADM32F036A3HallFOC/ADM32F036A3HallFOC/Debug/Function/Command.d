# FIXED

Function/Command.obj: ../Function/Command.c
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Define.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/RunSrc.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Device.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Adc.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_BootVars.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_DevEmu.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Cla.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Comp.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_CpuTimers.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_ECan.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_ECap.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_EPwm.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_EQep.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Gpio.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_I2c.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Lin.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_NmiIntrupt.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PieCtrl.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PieVect.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Spi.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Sci.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_SysCtrl.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_XIntrupt.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PgaOpa.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Reference.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Parameter.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Main.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Interface.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/MotorInclude.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/MainInclude.h
Function/Command.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/SubPrgInclude.h

../Function/Command.c: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Define.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/RunSrc.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Device.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Adc.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_BootVars.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_DevEmu.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Cla.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Comp.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_CpuTimers.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_ECan.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_ECap.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_EPwm.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_EQep.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Gpio.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_I2c.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Lin.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_NmiIntrupt.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PieCtrl.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PieVect.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Spi.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Sci.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_SysCtrl.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_XIntrupt.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PgaOpa.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Reference.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Parameter.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Main.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Interface.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/MotorInclude.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/MainInclude.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/SubPrgInclude.h: 

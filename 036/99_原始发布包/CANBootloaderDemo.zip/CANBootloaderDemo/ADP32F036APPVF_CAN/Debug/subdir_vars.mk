################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../ADP32F03xPeripheral.cmd \
../ADP32F03x_BOOTLOAD.cmd 



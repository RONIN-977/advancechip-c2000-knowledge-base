################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
Motor/src/%.obj: ../Motor/src/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/CCS8.2/ccsv8/tools/compiler/ti-cgt-c2000_18.1.3.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla0 -Ooff --opt_for_speed=3 --include_path="C:/Users/Allen1/Desktop/ADM32F036A3HallFOC/ADM32F036A3HallFOC" --include_path="C:/Users/Allen1/Desktop/ADM32F036A3HallFOC/ADM32F036A3HallFOC/HeardFiles/SourceHeader" --include_path="C:/Users/Allen1/Desktop/ADM32F036A3HallFOC/ADM32F036A3HallFOC/HeardFiles/280xHeader" --include_path="C:/CCS8.2/ccsv8/tools/compiler/ti-cgt-c2000_18.1.3.LTS/include" --advice:performance=all --define=SHORT_GND_TEST_N --define=LOW_NOISE_PWM_MODE --define=INTER_OSC --define=KE_WIDE_RANGE --define=IPD_PERIOD_AUTO_DECT_N --define=FREQUENCY_CONTROL_01HZ --define=CUT_DOWN_VER_HARDWARE --define=OPEN_LOOP_START_N --define=FULL_OPEN_LOOP_MODE_N --define=LIN_CONTROL_MODE --define=INTER_OSC11 --define="LARGE_MODEL" -g --diag_warning=225 --diag_wrap=off --display_error_number --preproc_with_compile --preproc_dependency="Motor/src/$(basename $(<F)).d_raw" --obj_directory="Motor/src" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '



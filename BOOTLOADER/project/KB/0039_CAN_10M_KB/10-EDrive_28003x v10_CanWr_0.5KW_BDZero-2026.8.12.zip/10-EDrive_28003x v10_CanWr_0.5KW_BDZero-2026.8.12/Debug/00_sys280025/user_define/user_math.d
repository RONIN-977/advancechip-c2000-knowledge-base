# FIXED

00_sys280025/user_define/user_math.obj: ../00_sys280025/user_define/user_math.c
00_sys280025/user_define/user_math.obj: ../00_sys280025/user_define/user_math.h
00_sys280025/user_define/user_math.obj: E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x\ v10_CanWr_0.5KW_BDZero-2026.8.12/00_sys280025/math_Lib/IQmathLib.h
00_sys280025/user_define/user_math.obj: D:/ti/ccs1110/ccs/tools/compiler/ti-cgt-c2000_21.6.0.LTS/include/limits.h
00_sys280025/user_define/user_math.obj: D:/ti/ccs1110/ccs/tools/compiler/ti-cgt-c2000_21.6.0.LTS/include/_ti_config.h
00_sys280025/user_define/user_math.obj: D:/ti/ccs1110/ccs/tools/compiler/ti-cgt-c2000_21.6.0.LTS/include/linkage.h
00_sys280025/user_define/user_math.obj: ../00_sys280025/user_define/DataTypeDef.h

../00_sys280025/user_define/user_math.c:

../00_sys280025/user_define/user_math.h:

E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x\ v10_CanWr_0.5KW_BDZero-2026.8.12/00_sys280025/math_Lib/IQmathLib.h:

D:/ti/ccs1110/ccs/tools/compiler/ti-cgt-c2000_21.6.0.LTS/include/limits.h:

D:/ti/ccs1110/ccs/tools/compiler/ti-cgt-c2000_21.6.0.LTS/include/_ti_config.h:

D:/ti/ccs1110/ccs/tools/compiler/ti-cgt-c2000_21.6.0.LTS/include/linkage.h:

../00_sys280025/user_define/DataTypeDef.h:


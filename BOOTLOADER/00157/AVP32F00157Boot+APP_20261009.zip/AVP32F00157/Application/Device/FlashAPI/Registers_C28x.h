/*--------------------------------------------------------*/
/* F65\Registers_C28x.h                                  */
/* F65 Flash API v2.00                                  */
/*--------------------------------------------------------*/

// $TI Release: F280015x Support Library v5.05.00.00 $
// 
// $Copyright:
// Copyright (C) 2023 Texas Instruments Incorporated - http://www.ti.com/
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $

/*!
    \file F65\Registers_C28x.h
    \brief A complete mapping of the F65 Flash Registers

    Allows named access to the F65 Flash Registers.
*/
#ifndef F65_REGISTERS_C28X_H_
#define F65_REGISTERS_C28X_H_

#ifdef __cplusplus
extern "C"
{
#endif

/*  Flash Configuration Registers */

/*typedef union Fapi_Register*/
/*!
    Structure describing the Flash Wrapper registers allowing register and bit
    level accesses.
*/

typedef volatile struct NW_BASE_REGISTERS
{

      uint32 u32Register; 
} Fapi_FmcRegistersType;

#ifdef __cplusplus
}
#endif /* extern "C" */

#endif /*F65_REGISTERS_C28X_H_*/

################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -llibc.a -l"D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/LIB/Flash2806x_API_V100_FLASH.lib"


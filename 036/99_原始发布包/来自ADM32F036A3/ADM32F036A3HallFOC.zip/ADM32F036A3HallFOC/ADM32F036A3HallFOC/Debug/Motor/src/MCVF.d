# FIXED

Motor/src/MCVF.obj: ../Motor/src/MCVF.c
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/MotorInclude.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/MainInclude.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Define.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Device.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Adc.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_BootVars.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_DevEmu.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Cla.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Comp.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_CpuTimers.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_ECan.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_ECap.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_EPwm.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_EQep.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Gpio.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_I2c.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Lin.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_NmiIntrupt.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PieCtrl.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PieVect.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Spi.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Sci.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_SysCtrl.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_XIntrupt.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PgaOpa.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Parameter.h
Motor/src/MCVF.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/SubPrgInclude.h

../Motor/src/MCVF.c: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/MotorInclude.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/MainInclude.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Define.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Device.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Adc.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_BootVars.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_DevEmu.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Cla.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Comp.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_CpuTimers.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_ECan.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_ECap.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_EPwm.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_EQep.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Gpio.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_I2c.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Lin.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_NmiIntrupt.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PieCtrl.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PieVect.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Spi.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Sci.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_SysCtrl.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_XIntrupt.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PgaOpa.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Parameter.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/SubPrgInclude.h: 

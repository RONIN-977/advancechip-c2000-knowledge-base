################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
Function/%.obj: ../Function/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"D:/CCS11.00/softwaresetup/ccs/tools/compiler/ti-cgt-c2000_21.6.0.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla0 -O2 --opt_for_speed=3 --include_path="E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928" --include_path="E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/SourceHeader" --include_path="E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/Library" --include_path="E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader" --include_path="D:/CCS11.00/softwaresetup/ccs/tools/compiler/ti-cgt-c2000_21.6.0.LTS/include" --advice:performance=all --define=IPD_PERIOD_AUTO_DECT_N --define=LOW_NOISE_PWM_MODE --define=KE_WIDE_RANGE --define=CUT_DOWN_VER_HARDWARE --define=SHORT_GND_TEST_N --define=OPEN_LOOP_START_N --define=LIN_CONTROL_MODE_N --define=FULL_OPEN_LOOP_MODE_N --define=INTER_OSC --define=LARGE_MODEL -g --diag_warning=225 --diag_wrap=off --display_error_number --abi=coffabi --preproc_with_compile --preproc_dependency="Function/$(basename $(<F)).d_raw" --obj_directory="Function" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '



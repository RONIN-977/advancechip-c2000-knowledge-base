#ifndef DEBUG_CFG_H_H_
#define DEBUG_CFG_H_H_


#define DEBUG_EN	0  //DEBUG_EN Ϊ1ʹ��Debugģʽ,Ϊ0ʹ��Flash�̻�ģʽ

#endif


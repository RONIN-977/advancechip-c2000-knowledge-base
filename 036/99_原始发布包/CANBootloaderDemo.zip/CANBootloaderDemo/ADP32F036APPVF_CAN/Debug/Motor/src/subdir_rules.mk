################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
Motor/src/%.obj: ../Motor/src/%.c $(GEN_OPTS) | $(GEN_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"D:/ti/ccsv8/tools/compiler/ti-cgt-c2000_18.1.4.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla0 -Ooff --opt_for_speed=3 --include_path="C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036APPVF_CAN/HeardFiles/ADP32F03xHeader" --include_path="C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036APPVF_CAN" --include_path="C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036APPVF_CAN/HeardFiles/SourceHeader" --include_path="D:/ti/ccsv8/tools/compiler/ti-cgt-c2000_18.1.4.LTS/include" --advice:performance=all --define=SHORT_GND_TEST_N --define=IPD_PERIOD_AUTO_DECT_N --define=LOW_NOISE_PWM_MODE_N --define=INTER_OSC --define=KE_WIDE_RANGE --define=IPD_PERIOD_AUTO_DECT_N --define=FREQUENCY_CONTROL_01HZ --define=CUT_DOWN_VER_HARDWARE --define=OPEN_LOOP_START_N --define=FULL_OPEN_LOOP_MODE_N --define=LIN_CONTROL_MODE --define=INTER_OSC11 --define="LARGE_MODEL" -g --diag_warning=225 --diag_wrap=off --display_error_number --preproc_with_compile --preproc_dependency="Motor/src/$(basename $(<F)).d_raw" --obj_directory="Motor/src" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '



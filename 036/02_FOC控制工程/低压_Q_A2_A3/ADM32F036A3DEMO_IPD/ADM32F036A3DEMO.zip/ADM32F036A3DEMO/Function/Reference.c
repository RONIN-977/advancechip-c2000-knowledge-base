
#include "Define.h"
#include "Reference.h"
#include "Main.h"
#include "RunSrc.h"
#include "Parameter.h"
#include "LinLDF.h"
#include "MotorInclude.h"

int32 frq;
int32 frqTmp;
int32 frqAim;
int32 frqAimTmp;
int32 frqAimTmp0;
int32 frqCurAim;

Uint32 upperFrq;        // ����Ƶ��
Uint16 lowerFrq;        // ����Ƶ��
Uint32 maxFrq;          // ���Ƶ��
Uint16 upperTorque;     // �ٶȿ���ʱΪת�����ޣ�ת�ؿ���ʱΪ�趨ת��


void UpdateLimitFrq(void);
void TorqueCalc(void);

void FrqSrcDeal(void)
{
	// ������Ƶ�ʼ���
    UpdateLimitFrq();

	// ת�����޼���
    TorqueCalc();

	// Ƶ��Դ����
    frqAimTmp0 = RefSet;//GetSetupFreComs();

#ifndef OPEN_LOOP_START
    if (TimeAccumulator.count_1s < 5) {
        SetAccTimes(ACC1);//ACC1);
    } else {
        SetAccTimes(ACC2);
    }
#else
    if (gMainStatus.RunStep == OPEN_ACC || gMainStatus.RunStep == HALF_OPEN_ACC) {
        SetAccTimes(ACC1);
    } else {
        SetAccTimes(ACC1);
    }
#endif

    // �ж��Ƿ񳬹�����Ƶ��
    if (frqAimTmp0 > (int32)upperFrq) {
        frqAimTmp0 = (int32)upperFrq;
    } else if (frqAimTmp0 < -(int32)upperFrq) {
        frqAimTmp0 = -(int32)upperFrq;
	}

	// ��ֵ��frqAimTmp
    frqAimTmp = frqAimTmp0;
}

void UpdateFrqSetAim(void)
{
	// ���з���
    if (FORWARD_DIR != runCmd.bit.dir) {
        frqAimTmp = -frqAimTmp;
    }   
	// �ж��Ƿ񳬹�����Ƶ��
    if ((frqAimTmp > upperFrq)&&(frqAimTmp > 0)) {
        frqAimTmp = upperFrq;
    } else if (frqAimTmp < -(int32)upperFrq) {
        frqAimTmp = -(int32)upperFrq;
	}
	// ��ֵ��frqAim
    frqAim = frqAimTmp;
}

//long PowerLimitData[10];
void POE_Limit(long PowerValve,long PowerKp,long PowerKi, long *PowerLimitOut)
{
    long PowerError;
    static long LastPowerError = 0;
    long PowerErrorDiff;
    static long PowerIntergral = 0;
    int PowerLimitIqHigh;
    int PowerLimitIqLow;
    long P_Term, I_Term, D_Term,Output;

    PowerLimitIqHigh = 4000;
    PowerLimitIqLow  = 0;

    // �������
    PowerError = ActualPower - PowerValve;
    PowerError = __IQsat(PowerError, 1500L, -1500L);    // 100.0W

    // �������仯�ʣ�����΢�֣�
    PowerErrorDiff = PowerError - LastPowerError;
    LastPowerError = PowerError;

    // ������
    P_Term = ((long long)PowerError * PowerKp) >> 8;

    // �Ա仯�ʽ����޷���ƽ��
    PowerErrorDiff = __IQsat(PowerErrorDiff, 200L, -200L);  // ���Ʊ仯��

    PowerIntergral = PowerIntergral + (PowerError * (long)PowerKi);

    // �����޷�
    PowerIntergral = __IQsat(PowerIntergral,PowerLimitIqHigh * 256L,PowerLimitIqLow * 256L);

    // ������
    I_Term = (long)PowerIntergral >> 8;

    // ΢����
    D_Term = ((long long)PowerErrorDiff * PowerKp) >> 8;

    // �ܺ�
    Output = I_Term + P_Term + D_Term;

    // ����޷�
    Output = __IQsat(Output,PowerLimitIqHigh,PowerLimitIqLow);

    *PowerLimitOut = Output;
}

void TorqueCalc(void)
{
#if 0
    int TorqueSet;
    if (generatrixVoltage > 3000) {
        TorqueSet = 10240;
    } else if (generatrixVoltage < 2600) {
        TorqueSet = 8000;
    } else {
        // TorqueSet = ((long)(generatrixVoltage - 2600) * 224) / 400;
        TorqueSet = ((long)(generatrixVoltage - 2600) * 5730) >> 10;
        TorqueSet += 8000;
        if (TorqueSet > 10240) {
            TorqueSet = 10240;
        } else if (TorqueSet < 8000) {
            TorqueSet = 8000;
        }
    }
    TorqueSet = ((long)TorqueSet * TorqueLimitSet) >> 10;
    static long TorqueSetAcc = 1024UL << 16;
    TorqueSetAcc = ((((int32)TorqueSet << 16) - TorqueSetAcc) >> 5) + TorqueSetAcc;
    TorqueSet  = (TorqueSetAcc + 0x8000) >> 16;

	upperTorque = TorqueSet;
#else
    // 110V����ʱ����ֵ��
    upperTorque = TORQUE_CUR_LIMIT * 10;
#endif
}

void UpdateLimitFrq(void)
{
    maxFrq = MAX_LIMIT_FREQ;
    upperFrq = MAX_LIMIT_FREQ;
    lowerFrq = LOWER_LIMIT_FREQ;
}

################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
ASM_SRCS += \
../Library/Per_Src/AVP32F069_CSMPasswords.asm \
../Library/Per_Src/AVP32F069_CodeStartBranch.asm \
../Library/Per_Src/AVP32F069_DBGIER.asm \
../Library/Per_Src/AVP32F069_DisInt.asm \
../Library/Per_Src/AVP32F069_usDelay.asm 

C_SRCS += \
../Library/Per_Src/AVP32F069_Adc.c \
../Library/Per_Src/AVP32F069_Comp.c \
../Library/Per_Src/AVP32F069_CpuTimers.c \
../Library/Per_Src/AVP32F069_DefaultIsr.c \
../Library/Per_Src/AVP32F069_Dma.c \
../Library/Per_Src/AVP32F069_ECan.c \
../Library/Per_Src/AVP32F069_ECap.c \
../Library/Per_Src/AVP32F069_EPwm.c \
../Library/Per_Src/AVP32F069_EQep.c \
../Library/Per_Src/AVP32F069_GlobalVariableDefs.c \
../Library/Per_Src/AVP32F069_Gpio.c \
../Library/Per_Src/AVP32F069_HRCap.c \
../Library/Per_Src/AVP32F069_I2C.c \
../Library/Per_Src/AVP32F069_Mcbsp.c \
../Library/Per_Src/AVP32F069_OscComp.c \
../Library/Per_Src/AVP32F069_PieCtrl.c \
../Library/Per_Src/AVP32F069_PieVect.c \
../Library/Per_Src/AVP32F069_Sci.c \
../Library/Per_Src/AVP32F069_Spi.c \
../Library/Per_Src/AVP32F069_SysCtrl.c \
../Library/Per_Src/AVP32F069_TempSensorConv.c 

C_DEPS += \
./Library/Per_Src/AVP32F069_Adc.d \
./Library/Per_Src/AVP32F069_Comp.d \
./Library/Per_Src/AVP32F069_CpuTimers.d \
./Library/Per_Src/AVP32F069_DefaultIsr.d \
./Library/Per_Src/AVP32F069_Dma.d \
./Library/Per_Src/AVP32F069_ECan.d \
./Library/Per_Src/AVP32F069_ECap.d \
./Library/Per_Src/AVP32F069_EPwm.d \
./Library/Per_Src/AVP32F069_EQep.d \
./Library/Per_Src/AVP32F069_GlobalVariableDefs.d \
./Library/Per_Src/AVP32F069_Gpio.d \
./Library/Per_Src/AVP32F069_HRCap.d \
./Library/Per_Src/AVP32F069_I2C.d \
./Library/Per_Src/AVP32F069_Mcbsp.d \
./Library/Per_Src/AVP32F069_OscComp.d \
./Library/Per_Src/AVP32F069_PieCtrl.d \
./Library/Per_Src/AVP32F069_PieVect.d \
./Library/Per_Src/AVP32F069_Sci.d \
./Library/Per_Src/AVP32F069_Spi.d \
./Library/Per_Src/AVP32F069_SysCtrl.d \
./Library/Per_Src/AVP32F069_TempSensorConv.d 

OBJS += \
./Library/Per_Src/AVP32F069_Adc.obj \
./Library/Per_Src/AVP32F069_CSMPasswords.obj \
./Library/Per_Src/AVP32F069_CodeStartBranch.obj \
./Library/Per_Src/AVP32F069_Comp.obj \
./Library/Per_Src/AVP32F069_CpuTimers.obj \
./Library/Per_Src/AVP32F069_DBGIER.obj \
./Library/Per_Src/AVP32F069_DefaultIsr.obj \
./Library/Per_Src/AVP32F069_DisInt.obj \
./Library/Per_Src/AVP32F069_Dma.obj \
./Library/Per_Src/AVP32F069_ECan.obj \
./Library/Per_Src/AVP32F069_ECap.obj \
./Library/Per_Src/AVP32F069_EPwm.obj \
./Library/Per_Src/AVP32F069_EQep.obj \
./Library/Per_Src/AVP32F069_GlobalVariableDefs.obj \
./Library/Per_Src/AVP32F069_Gpio.obj \
./Library/Per_Src/AVP32F069_HRCap.obj \
./Library/Per_Src/AVP32F069_I2C.obj \
./Library/Per_Src/AVP32F069_Mcbsp.obj \
./Library/Per_Src/AVP32F069_OscComp.obj \
./Library/Per_Src/AVP32F069_PieCtrl.obj \
./Library/Per_Src/AVP32F069_PieVect.obj \
./Library/Per_Src/AVP32F069_Sci.obj \
./Library/Per_Src/AVP32F069_Spi.obj \
./Library/Per_Src/AVP32F069_SysCtrl.obj \
./Library/Per_Src/AVP32F069_TempSensorConv.obj \
./Library/Per_Src/AVP32F069_usDelay.obj 

ASM_DEPS += \
./Library/Per_Src/AVP32F069_CSMPasswords.d \
./Library/Per_Src/AVP32F069_CodeStartBranch.d \
./Library/Per_Src/AVP32F069_DBGIER.d \
./Library/Per_Src/AVP32F069_DisInt.d \
./Library/Per_Src/AVP32F069_usDelay.d 

OBJS__QUOTED += \
"Library\Per_Src\AVP32F069_Adc.obj" \
"Library\Per_Src\AVP32F069_CSMPasswords.obj" \
"Library\Per_Src\AVP32F069_CodeStartBranch.obj" \
"Library\Per_Src\AVP32F069_Comp.obj" \
"Library\Per_Src\AVP32F069_CpuTimers.obj" \
"Library\Per_Src\AVP32F069_DBGIER.obj" \
"Library\Per_Src\AVP32F069_DefaultIsr.obj" \
"Library\Per_Src\AVP32F069_DisInt.obj" \
"Library\Per_Src\AVP32F069_Dma.obj" \
"Library\Per_Src\AVP32F069_ECan.obj" \
"Library\Per_Src\AVP32F069_ECap.obj" \
"Library\Per_Src\AVP32F069_EPwm.obj" \
"Library\Per_Src\AVP32F069_EQep.obj" \
"Library\Per_Src\AVP32F069_GlobalVariableDefs.obj" \
"Library\Per_Src\AVP32F069_Gpio.obj" \
"Library\Per_Src\AVP32F069_HRCap.obj" \
"Library\Per_Src\AVP32F069_I2C.obj" \
"Library\Per_Src\AVP32F069_Mcbsp.obj" \
"Library\Per_Src\AVP32F069_OscComp.obj" \
"Library\Per_Src\AVP32F069_PieCtrl.obj" \
"Library\Per_Src\AVP32F069_PieVect.obj" \
"Library\Per_Src\AVP32F069_Sci.obj" \
"Library\Per_Src\AVP32F069_Spi.obj" \
"Library\Per_Src\AVP32F069_SysCtrl.obj" \
"Library\Per_Src\AVP32F069_TempSensorConv.obj" \
"Library\Per_Src\AVP32F069_usDelay.obj" 

C_DEPS__QUOTED += \
"Library\Per_Src\AVP32F069_Adc.d" \
"Library\Per_Src\AVP32F069_Comp.d" \
"Library\Per_Src\AVP32F069_CpuTimers.d" \
"Library\Per_Src\AVP32F069_DefaultIsr.d" \
"Library\Per_Src\AVP32F069_Dma.d" \
"Library\Per_Src\AVP32F069_ECan.d" \
"Library\Per_Src\AVP32F069_ECap.d" \
"Library\Per_Src\AVP32F069_EPwm.d" \
"Library\Per_Src\AVP32F069_EQep.d" \
"Library\Per_Src\AVP32F069_GlobalVariableDefs.d" \
"Library\Per_Src\AVP32F069_Gpio.d" \
"Library\Per_Src\AVP32F069_HRCap.d" \
"Library\Per_Src\AVP32F069_I2C.d" \
"Library\Per_Src\AVP32F069_Mcbsp.d" \
"Library\Per_Src\AVP32F069_OscComp.d" \
"Library\Per_Src\AVP32F069_PieCtrl.d" \
"Library\Per_Src\AVP32F069_PieVect.d" \
"Library\Per_Src\AVP32F069_Sci.d" \
"Library\Per_Src\AVP32F069_Spi.d" \
"Library\Per_Src\AVP32F069_SysCtrl.d" \
"Library\Per_Src\AVP32F069_TempSensorConv.d" 

ASM_DEPS__QUOTED += \
"Library\Per_Src\AVP32F069_CSMPasswords.d" \
"Library\Per_Src\AVP32F069_CodeStartBranch.d" \
"Library\Per_Src\AVP32F069_DBGIER.d" \
"Library\Per_Src\AVP32F069_DisInt.d" \
"Library\Per_Src\AVP32F069_usDelay.d" 

C_SRCS__QUOTED += \
"../Library/Per_Src/AVP32F069_Adc.c" \
"../Library/Per_Src/AVP32F069_Comp.c" \
"../Library/Per_Src/AVP32F069_CpuTimers.c" \
"../Library/Per_Src/AVP32F069_DefaultIsr.c" \
"../Library/Per_Src/AVP32F069_Dma.c" \
"../Library/Per_Src/AVP32F069_ECan.c" \
"../Library/Per_Src/AVP32F069_ECap.c" \
"../Library/Per_Src/AVP32F069_EPwm.c" \
"../Library/Per_Src/AVP32F069_EQep.c" \
"../Library/Per_Src/AVP32F069_GlobalVariableDefs.c" \
"../Library/Per_Src/AVP32F069_Gpio.c" \
"../Library/Per_Src/AVP32F069_HRCap.c" \
"../Library/Per_Src/AVP32F069_I2C.c" \
"../Library/Per_Src/AVP32F069_Mcbsp.c" \
"../Library/Per_Src/AVP32F069_OscComp.c" \
"../Library/Per_Src/AVP32F069_PieCtrl.c" \
"../Library/Per_Src/AVP32F069_PieVect.c" \
"../Library/Per_Src/AVP32F069_Sci.c" \
"../Library/Per_Src/AVP32F069_Spi.c" \
"../Library/Per_Src/AVP32F069_SysCtrl.c" \
"../Library/Per_Src/AVP32F069_TempSensorConv.c" 

ASM_SRCS__QUOTED += \
"../Library/Per_Src/AVP32F069_CSMPasswords.asm" \
"../Library/Per_Src/AVP32F069_CodeStartBranch.asm" \
"../Library/Per_Src/AVP32F069_DBGIER.asm" \
"../Library/Per_Src/AVP32F069_DisInt.asm" \
"../Library/Per_Src/AVP32F069_usDelay.asm" 



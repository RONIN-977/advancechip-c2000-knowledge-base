/*******************************************************************************
 * config.c
 *
 * Modification: 
 *    Date     : 
 *    Revision :
 *    Author   :
 *    Contents :
 *******************************************************************************/



/* ========================================================================== */
/*                             ͷ�ļ���                                       */
/* ========================================================================== */

#include "osa.h"
#include "config.h"
//#include "crc16.h"
//#include "Platform_Types.h"
#include "flash_hal.h"
//#include "api_eeprom.h"


/* ========================================================================== */
/*                           ������Ͷ�����                                   */
/* ========================================================================== */

/* ���ÿ��ƽṹ�壬��СΪ4�ֽ� */
typedef struct configure_control_t
{
	u32 magicNumber;	/* ħ����������Ϊ`A00` */
} Configure_Control;


typedef struct configure_context_t
{
	Configure_Control control;
	Bootloader_Configuration config;
} Configure_Context;


/* ========================================================================== */
/*                          ���ݽṹ������                                    */
/* ========================================================================== */

Configure_Context s_configureContext;

u32 config_addr()
{
    return 0x085000U;
}
/* ========================================================================== */
/*                          ����������                                        */
/* ========================================================================== */

/*******************************************************************************
* ������  : config_load
* ��  ��  : �����������м������õ��ڴ���
* ��  ��  : ��
* ��  ��  : ��
* ����ֵ  : OSA_SOK  : �ɹ�
*           OSA_EFAIL: ʧ��
*******************************************************************************/
int config_load(void)
{
    Configure_Context *pFConfig = (Configure_Context *)config_addr();
    Configure_Context *pContext = &s_configureContext;

    memcpy((uint8 *)pContext, (uint8 *)pFConfig, sizeof(Configure_Context)/2);

    if (pContext->control.magicNumber != BOOTLOADER_MAGIC)
    {
        memset((uint8 *)pContext, 0xFF, sizeof(Configure_Context));

        pContext->control.magicNumber = 0X3041;//0x454c;
        pContext->config.bootDirectFlags = BOOTLOADER_NON_PROG_REQ;
        //pContext->config.configCrc = crc16((uint8_t *)&pContext->config, CONFIG_DATA_SIZE - sizeof(uint32_t));

//        return E2PROM_write(0, sizeof(Configure_Context), (uint8_t *)pContext);
    }

    return OSA_SOK;
}



/*******************************************************************************
* ������  : config_set
* ��  ��  : ���ò�������������
* ��  ��  : - pData      : ������ָ��Bootloader_Configuration�ṹ��ָ��
*         : - commandSize: ������С��pData��С������Ϊsizeof(Bootloader_Configuration)
*         : - commandMask: �����������룬֧�ֶ������һ�����ã��ο�Bootloader_Command
* ��  ��  : ��
* ����ֵ  : OSA_SOK  : �ɹ�
*           OSA_EFAIL: ʧ��
*******************************************************************************/
int config_set(u8 * pData, u32 commandSize, u32 commandMask)
{
	Bootloader_Configuration *pUsrConfig = (Bootloader_Configuration *)pData;
	Configure_Context *pContext = &s_configureContext;
	Bootloader_Configuration *pConfig = NULL;

	if (pContext->control.magicNumber != 0X3041)//0x454c
	{
		return OSA_EFAIL;
	}

	pConfig = &pContext->config;

	if (BL_CONFIG_BOOT_FLAG & commandMask)
	{
		pConfig->bootDirectFlags = pUsrConfig->bootDirectFlags;
	}

	if (BL_CONFIG_CRC & commandMask)
	{
		pConfig->crcByteCount     = pUsrConfig->crcByteCount;
		pConfig->crcExpectedValue = pUsrConfig->crcExpectedValue;
		pConfig->crcStartAddress  = pUsrConfig->crcStartAddress;
	}

	if (BL_CONFIG_PROG_DATE & commandMask)
	{
		memcpy(pConfig->programmingDate, pUsrConfig->programmingDate, 4);
	}

	if (BL_CONFIG_FINGER_PRINT & commandMask)
	{
		memcpy(pConfig->appSoftwareFingerprint, pUsrConfig->appSoftwareFingerprint, 16);
	}

	if (BL_CONFIG_APP_VERSION & commandMask)
	{
		memcpy(pConfig->appSoftwareVersion, pUsrConfig->appSoftwareVersion, 10);
	}

	//pConfig->configCrc = crc16((uint8_t *)pConfig, CONFIG_DATA_SIZE - sizeof(uint32_t));

    flash_hal_erase(0x85000U,0x1000);
    flash_hal_write(0x85000U,sizeof(Configure_Context),(uint8 *)pContext);
    return 0;

//    if(flash_hal_erase(config_addr(),0x1000) != 0)
//    {
//        return  flash_hal_write(config_addr(),sizeof(Configure_Context),(uint8 *)pContext);
//    }
//    else
//    {
//        return 1;
//    }
//    return E2PROM_write(0, sizeof(Configure_Context), (uint8_t *)pContext);
}


/*******************************************************************************
* ������  : config_get
* ��  ��  : ��EEPROM�еĲ���
* ��  ��  : ��
* ��  ��  : ��
* ����ֵ  : OSA_SOK  : �ɹ�
*           OSA_EFAIL: ʧ��
*******************************************************************************/
int config_get(Bootloader_Configuration *pUsrConfig)
{
	Configure_Context *pContext = &s_configureContext;

	if (NULL == pUsrConfig)
	{
		return OSA_EINVAL;
	}

	memcpy(pUsrConfig, &pContext->config, sizeof(Bootloader_Configuration));
	
	return OSA_SOK;
}


/*******************************************************************************
* ������  : config_isDirectBoot
* ��  ��  : �Ƿ���ֱ������ģʽ
* ��  ��  : ��
* ��  ��  : ��
* ����ֵ  : true  : ֱ������Ӧ��
*           false : ������Ӧ�ã��ȴ�����
*******************************************************************************/
bool config_isDirectBoot(void)
{
	Configure_Context *pContext = &s_configureContext;

	return (pContext->config.bootDirectFlags == BOOTLOADER_PROG_REQ);
}





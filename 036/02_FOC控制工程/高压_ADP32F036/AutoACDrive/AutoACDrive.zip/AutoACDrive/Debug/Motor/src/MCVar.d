# FIXED

Motor/src/MCVar.obj: ../Motor/src/MCVar.c
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/SourceHeader/MotorInclude.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/SourceHeader/MainInclude.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/SourceHeader/Define.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/SourceHeader/SubPrgInclude.h
Motor/src/MCVar.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/SourceHeader/param_lr.h

../Motor/src/MCVar.c:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/SourceHeader/MotorInclude.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/SourceHeader/MainInclude.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/SourceHeader/Define.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/SourceHeader/SubPrgInclude.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/SourceHeader/param_lr.h:


# FIXED

01_main/main.obj: ../01_main/main.c
01_main/main.obj: ../01_main/main.h

../01_main/main.c:

../01_main/main.h:


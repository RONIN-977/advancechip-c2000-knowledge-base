# FIXED

SubProgra/Record.obj: ../SubProgra/Record.c
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/SourceHeader/Record.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
SubProgra/Record.obj: C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h

../SubProgra/Record.c:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/SourceHeader/Record.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

C:/Users/Allen1/Desktop/chip_information/ADP32F036/ADP036/AutoACDrive/AutoACDrive/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:


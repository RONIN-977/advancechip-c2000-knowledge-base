################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
OBJ_SRCS += \
../Motor/src/HALL/AngleMeasHall.obj \
../Motor/src/HALL/HallHandle.obj \
../Motor/src/HALL/SpeedMeasHall.obj 



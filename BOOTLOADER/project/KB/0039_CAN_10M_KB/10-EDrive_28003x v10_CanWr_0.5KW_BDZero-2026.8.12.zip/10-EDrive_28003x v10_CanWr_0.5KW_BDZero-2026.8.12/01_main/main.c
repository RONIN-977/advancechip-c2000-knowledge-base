/*
 * main.c
 *
 *  Created on: Feb 9, 2022
 *      Author: rand C
 */

#include "main.h"
#include "NVM.h"
#include <05_Input/eeprom.h>

u8 HwFo_trigger = 0;
u16  TaskCycle;
void main(void){
    u32  Tick_Realtime,Tick_Interval;
    u16  m_TickCnt;

    // Initialize device clock and peripherals
    //
    InitSysCtrl();
    SysCtl_setLowSpeedClock(SYSCTL_LSPCLK_PRESCALE_4);

//    DINT; // DINT is performed in PIE Init func
    InitPeriherals();
	flash_hal_init();
    ResDemodulation_Init();
    EepromDataRead();
    EALLOW;
    WdRegs.WDCR.all = 0x0028;
    EDIS;
    EINT;
    ERTM;  // Enable Global realtime interrupt DBGM

    Task_App_Init();
    config_load();
    TaskCycle = 0;
    Tick_Realtime = SysTick();
    while(1){
        Tick_Interval = Tick_Realtime - SysTick();
        if (Tick_Interval > SYS_TICK_05MS){
            TaskCycle++;
            m_TickCnt = (TaskCycle & 0x03);
            Tick_Realtime -= SYS_TICK_05MS;
            ServiceDog();

            Task_App_05ms();

            if (0 == m_TickCnt)
            {
                Task_App_A_2ms();
                TpTx();
            }
            else if (1 == m_TickCnt) Task_App_B_2ms();
            else if (2 == m_TickCnt) Task_App_C_2ms();
            else Task_App_D_2ms();

        }
    }
}

__interrupt void ResAdcEndIsr(void){

    /*
     *  add user specific code here
    */
    ResDemodulation_ISR();

    // Clear the interrupt flag
   //
   AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;

   //
   // Check if overflow has occurred
   //
   if(1 == AdcaRegs.ADCINTOVF.bit.ADCINT1)
   {
       AdcaRegs.ADCINTOVFCLR.bit.ADCINT1 = 1; //clear INT1 overflow flag
       AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1; //clear INT1 flag
   }

   //
   // Acknowledge the interrupt
   //
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}

__interrupt void ResPwmIsr(void){

    /*
     *  add user specific code here
    */
    //ResDemodulation_ISR();

    EPwm4Regs.ETCLR.bit.INT = 1; /* clear ePWM peripheral flag */
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP3; /* clear PIE flag */

}

__interrupt void ResAdcFOCIsr(void){

    volatile u16 m_PIEIER;

    //if (0 == gRes_Diag.resInit_Pass){
    if (0 == gRes_Diag.ucResOffsetCheck){
        m_PIEIER = PieCtrlRegs.PIEIER1.all;

        IER |= M_INT1;
        IER &= M_INT1;

        PieCtrlRegs.PIEIER1.bit.INTx1 = 1;
        PieCtrlRegs.PIEACK.all = 0xFFFF;

        asm("       NOP");
        EINT;
    }

    /*
     *  add user specific code here
    */
    Task_FVC_ISR();

    // Clear the interrupt flag
   //
    AdccRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;

    //if (0 == gRes_Diag.resInit_Pass){
    if (0 == gRes_Diag.ucResOffsetCheck){
        DINT;
        PieCtrlRegs.PIEIER1.all = m_PIEIER;
    }

    //
    // Check if overflow has occurred
    //
    if(1 == AdccRegs.ADCINTOVF.bit.ADCINT1)
    {
       AdccRegs.ADCINTOVFCLR.bit.ADCINT1 = 1; //clear INT1 overflow flag
       AdccRegs.ADCINTFLGCLR.bit.ADCINT1 = 1; //clear INT1 flag
   }

   //
   // Acknowledge the interrupt
   //
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}

__interrupt void EPWMTZ_IsrTask(void)
{
    if((StateMachine.RuningState != STOP_STATE)&&((StateMachine.RuningState != ShutDown_STATE))){
        HwFo_trigger = 1;
    }

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP2;     // Acknowledge this interrupt
}

# F280039C 上位机便携版

适用 Windows 10/11 x64。完整解压后，双击 `Updater.Desktop.exe`。
随包包含 x64 .NET 桌面运行时、x86 CAN 桥接运行时、CANPRO 的 USBCAN 驱动库及 VC80 依赖、TI hex2000 转换工具；无需安装 CCS、Visual Studio、.NET 或 CANPRO。

默认使用 `drivers/zlg/x86/usbcan.dll`，不依赖原电脑 C 盘路径。可直接选择 `firmware/application.out` 进行升级；只选择固件不会擦写设备，点击“开始升级”才开始。

首次在新电脑连接 CAN 盒，若设备管理器尚未识别设备，请运行 `Install-USB-Driver.cmd` 并允许 Windows 管理员提示。系统 USB 驱动必须向 Windows 注册，不能仅靠复制 DLL 替代。随附驱动来自当前已安装的 ZLG USBCAN 驱动，匹配 USB VID_0471/PID_1200；其他型号或被 Windows 安全策略阻止的旧驱动需使用匹配的厂商驱动。不自动关闭系统安全设置。

窗口可拖动边框/右下角调整大小，也可最大化。最小尺寸 640×480；较小时可滚动查看完整操作区。

分发时请发送整个 ZIP，不要只发 EXE。所有第三方文件保留原样，许可材料见 `licenses`。本机验证不等同于全新电脑的硬件验收。

VC80 使用 Windows 标准并行程序集加载：已有系统运行库时可能优先使用系统版本；未安装时提供包内私有程序集。另随附 `drivers/vcredist_vs2005_sp1_x86.exe` 供出现并行配置错误的电脑修复环境，不在程序启动时自动安装。

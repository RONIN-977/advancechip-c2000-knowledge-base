# FIXED

01_main/02_can/debugCan.obj: ../01_main/02_can/debugCan.c
01_main/02_can/debugCan.obj: ../01_main/02_can/debugCan.h
01_main/02_can/debugCan.obj: E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x\ v10_CanWr_0.5KW_BDZero-2026.8.12/00_sys280025/user_define/DataTypeDef.h
01_main/02_can/debugCan.obj: ../01_main/02_can/can_message.h

../01_main/02_can/debugCan.c:

../01_main/02_can/debugCan.h:

E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x\ v10_CanWr_0.5KW_BDZero-2026.8.12/00_sys280025/user_define/DataTypeDef.h:

../01_main/02_can/can_message.h:


################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Delay.c \
../Example_ADP32F036PWM_AQ.c \
../printf_uart.c \
../pwm.c \
../timer0_base.c 

C_DEPS += \
./Delay.d \
./Example_ADP32F036PWM_AQ.d \
./printf_uart.d \
./pwm.d \
./timer0_base.d 

OBJS += \
./Delay.obj \
./Example_ADP32F036PWM_AQ.obj \
./printf_uart.obj \
./pwm.obj \
./timer0_base.obj 

OBJS__QUOTED += \
"Delay.obj" \
"Example_ADP32F036PWM_AQ.obj" \
"printf_uart.obj" \
"pwm.obj" \
"timer0_base.obj" 

C_DEPS__QUOTED += \
"Delay.d" \
"Example_ADP32F036PWM_AQ.d" \
"printf_uart.d" \
"pwm.d" \
"timer0_base.d" 

C_SRCS__QUOTED += \
"../Delay.c" \
"../Example_ADP32F036PWM_AQ.c" \
"../printf_uart.c" \
"../pwm.c" \
"../timer0_base.c" 



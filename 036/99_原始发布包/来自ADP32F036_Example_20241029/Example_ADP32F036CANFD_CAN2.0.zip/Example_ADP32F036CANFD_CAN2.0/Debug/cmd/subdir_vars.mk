################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../cmd/ADP32F035_FLASH.cmd \
../cmd/ADP32F03x_Headers_nonBIOS.cmd 



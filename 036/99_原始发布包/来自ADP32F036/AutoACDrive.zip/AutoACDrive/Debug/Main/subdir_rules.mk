################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
Main/%.obj: ../Main/%.asm $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"D:/CCS11.00/softwaresetup/ccs/tools/compiler/ti-cgt-c2000_21.6.0.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla0 -O2 --opt_for_speed=2 --include_path="E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release" --include_path="E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/Motor/StaticVModelObs" --include_path="E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader" --include_path="D:/CCS11.00/softwaresetup/ccs/tools/compiler/ti-cgt-c2000_21.6.0.LTS/include" --advice:performance=all --define=REFRIGERATOR --define=FIVEPWM_ENABLE_N --define=POSTIVE_DRIVE_LOGIC --define=VOL_800V_DEMO --define=ENABLE_NEW_STATIC_OBS_1 --define=OPEN_LOOP_START2 --define=SF_INDEPAND_OF_FREQUENCY_N --define=IPD_PERIOD_AUTO_DECT_N --define=INTER_OSC_N --define="LARGE_MODEL" -g --diag_warning=225 --diag_wrap=off --display_error_number --preproc_with_compile --preproc_dependency="Main/$(basename $(<F)).d_raw" --obj_directory="Main" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

Main/%.obj: ../Main/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"D:/CCS11.00/softwaresetup/ccs/tools/compiler/ti-cgt-c2000_21.6.0.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla0 -O2 --opt_for_speed=2 --include_path="E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release" --include_path="E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/Motor/StaticVModelObs" --include_path="E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader" --include_path="D:/CCS11.00/softwaresetup/ccs/tools/compiler/ti-cgt-c2000_21.6.0.LTS/include" --advice:performance=all --define=REFRIGERATOR --define=FIVEPWM_ENABLE_N --define=POSTIVE_DRIVE_LOGIC --define=VOL_800V_DEMO --define=ENABLE_NEW_STATIC_OBS_1 --define=OPEN_LOOP_START2 --define=SF_INDEPAND_OF_FREQUENCY_N --define=IPD_PERIOD_AUTO_DECT_N --define=INTER_OSC_N --define="LARGE_MODEL" -g --diag_warning=225 --diag_wrap=off --display_error_number --preproc_with_compile --preproc_dependency="Main/$(basename $(<F)).d_raw" --obj_directory="Main" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '



using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;
namespace Updater.Desktop;
public partial class App : Application
{
    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        var window = new MainWindow();
        if (e.Args.Length == 2 && e.Args[0] == "--self-check")
        {
            try
            {
                string converter = TiToolLocator.Find() ?? throw new FileNotFoundException("TI converter not found");
                string driver = CanDriver.DefaultPath;
                using (var bridge = new CanBridge(driver)) { }
                var firmware = await Updater.Core.TiOutConverter.LoadAsync(
                    Path.Combine(AppContext.BaseDirectory, "firmware", "application.out"), converter);
                File.WriteAllText(e.Args[1], System.Text.Json.JsonSerializer.Serialize(new
                {
                    Runtime = typeof(object).Assembly.Location,
                    Driver = driver,
                    Converter = converter,
                    firmware.EntryWordAddress,
                    WordCount = firmware.Words.Length,
                    ResizeMode = window.ResizeMode.ToString(),
                    window.MinWidth,
                    window.MinHeight
                }, new System.Text.Json.JsonSerializerOptions { WriteIndented = true }));
                Shutdown(0);
            }
            catch (Exception ex)
            {
                File.WriteAllText(e.Args[1], ex.ToString());
                Shutdown(1);
            }
            return;
        }
        if (e.Args.Length >= 2 && e.Args[0] == "--snapshot")
        {
            int width = e.Args.Length == 4 ? int.Parse(e.Args[2]) : 1080;
            int height = e.Args.Length == 4 ? int.Parse(e.Args[3]) : 800;
            var content = (FrameworkElement)window.Content;
            content.Measure(new Size(width, height)); content.Arrange(new Rect(0, 0, width, height)); content.UpdateLayout();
            var bitmap = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32);
            bitmap.Render(content);
            var png = new PngBitmapEncoder(); png.Frames.Add(BitmapFrame.Create(bitmap));
            using (var file = File.Create(e.Args[1])) png.Save(file);
            Shutdown(); return;
        }
        MainWindow = window; window.Show();
    }
}

# FIXED

Motor/src/InvProtect.obj: ../Motor/src/InvProtect.c
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/MotorInclude.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/MainInclude.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/Define.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Device.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Adc.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_BootVars.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_DevEmu.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Cla.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Comp.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_CpuTimers.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_ECan.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_ECap.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_EPwm.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_EQep.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Gpio.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_I2c.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Lin.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_NmiIntrupt.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_PieCtrl.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_PieVect.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Spi.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Sci.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_SysCtrl.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_XIntrupt.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_PgaOpa.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/SubPrgInclude.h
Motor/src/InvProtect.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/Record.h

../Motor/src/InvProtect.c:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/MotorInclude.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/MainInclude.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/Define.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Device.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Adc.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_BootVars.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_DevEmu.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Cla.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Comp.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_CpuTimers.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_ECan.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_ECap.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_EPwm.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_EQep.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Gpio.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_I2c.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Lin.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_NmiIntrupt.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_PieCtrl.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_PieVect.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Spi.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Sci.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_SysCtrl.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_XIntrupt.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_PgaOpa.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/SubPrgInclude.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/Record.h:


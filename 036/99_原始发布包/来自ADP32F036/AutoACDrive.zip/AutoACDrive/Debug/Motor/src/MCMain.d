# FIXED

Motor/src/MCMain.obj: ../Motor/src/MCMain.c
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/MotorInclude.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/MainInclude.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Define.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/SubPrgInclude.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/param_lr.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Main.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/FuncCode.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Debug.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/FuncCode.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Interface.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Parameter.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Record.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/Motor/StaticVModelObs/StaticVModelObs.h
Motor/src/MCMain.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/MCQpr.h

../Motor/src/MCMain.c:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/MotorInclude.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/MainInclude.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Define.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/SubPrgInclude.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/param_lr.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Main.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/FuncCode.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Debug.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/FuncCode.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Interface.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Parameter.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Record.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/Motor/StaticVModelObs/StaticVModelObs.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/MCQpr.h:


# FIXED

Function/Parameter_LingDong_3427_600VYaSuoJi.obj: ../Function/Parameter_LingDong_3427_600VYaSuoJi.c
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Define.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Main.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/FuncCode.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Debug.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/FuncCode.h
Function/Parameter_LingDong_3427_600VYaSuoJi.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Interface.h

../Function/Parameter_LingDong_3427_600VYaSuoJi.c:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Define.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Main.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/FuncCode.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Debug.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/FuncCode.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Interface.h:


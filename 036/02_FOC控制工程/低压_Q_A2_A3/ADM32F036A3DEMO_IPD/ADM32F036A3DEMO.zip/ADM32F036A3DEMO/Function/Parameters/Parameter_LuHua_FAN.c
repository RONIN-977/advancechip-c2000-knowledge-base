
/************************************************************************
 Project:             Automotive water pumps
 Filename:            LDF.c
 Partner Filename:    N/A
 Description:         Partner file of LDF.h
 Complier:            Code Composer Studio for ADM32F036, CCS Systems.
 CPU TYPE :           ADM32F036A2
*************************************************************************
 Copyright (c) 2024 **** Co., Ltd.
 All rights reserved.
*************************************************************************
*************************************************************************
 Revising History (ECL of this file):

************************************************************************/

/************************************************************************
 Beginning of File, do not put anything above here except notes
 Compiler Directives
*************************************************************************/

#include "Define.h"
#include "Main.h"

///////////////////////////////////////////////////////////////////////////////////////
// ���ư��������
///////////////////////////////////////////////////////////////////////////////////////
unsigned int MAX_DC_VOL_3_3V    =  471;           // 0.1vdc
#define  MAX_PEAK_CUR_3_3V           10000        // 0.01A
unsigned long MAX_PEAK_CUR_3_3V_2   =  MAX_PEAK_CUR_3_3V;
unsigned long MAX_PEAK_CUR_3_3V_410 =  ((long)MAX_PEAK_CUR_3_3V << 12) / 10;

unsigned int OVER_DC_VOL_POINT    =  180;         // 0.1vdc
unsigned int OVER_DC_VOL_LIMIT    =  160;         // 0.1vdc
unsigned int UNDER_DC_VOL_POINT   =  75;          // 0.1vdc
unsigned int  OVER_DC_VOL_KP      =  100;
unsigned int MaxAllowUdcLimit     =  170;
unsigned int MidAllowUdcLimit     =  155;

#define DEAD_TIME                    50                                  // ����ʱ�䣬0.50US
#define DEAD_COMPENATION_TIME        25                                  // ��������ʱ�䣬0.25US
unsigned int DeadTimeInternal     =  ((long)DEAD_TIME * DSP_CLOCK) / 100;               // ����ʱ��
unsigned int DeadTimeCompInternal =  ((long)DEAD_COMPENATION_TIME * DSP_CLOCK) / 100;   // ��������ʱ��

#define HARDWARE_OVER_CUR            9000                                // Ӳ�������Ƚ�ֵ��10.00A
#define HARDWARE_CBC_CUR             8000                                // CBC�����Ƚ�ֵ, 8.00A
unsigned int OverCurPointInternal =  ((long)HARDWARE_OVER_CUR << 9) / MAX_PEAK_CUR_3_3V + 512;   // Ӳ�������Ƚ�ֵ
unsigned int CBCCurPointInternal  =  ((long)HARDWARE_CBC_CUR  << 9) / MAX_PEAK_CUR_3_3V + 512;   // CBC�����Ƚ�ֵ

///////////////////////////////////////////////////////////////////////////////////////
// �����������
///////////////////////////////////////////////////////////////////////////////////////
unsigned int MOTOR_RATED_POWER  =  2000;    //0.1WΪ��λ
unsigned int MOTOR_RATED_VOL    =  8;
unsigned int MOTOR_RATED_CUR    =  200;
unsigned int LOWER_LIMIT_FREQ   =  0;

unsigned int PMSM_LD            =  50;//38;          // 76 --- 105
unsigned int PMSM_LQ            =  68;//53;          // 50uH
unsigned int PMSM_RS            =  25;//12;          // 11mohm
unsigned int PMS_L_R_UNIT       =  0;           //
#ifdef KE_WIDE_RANGE
unsigned int PMSM_KE            =  40;//45;          // Ke = 6.67
#else
unsigned int PMSM_KE            =  4;           // ke = 4
#endif

///////////////////////////////////////////////////////////////////////////////////////
// �����л��ջ���������
///////////////////////////////////////////////////////////////////////////////////////
unsigned int FRQ_OPEN_TO_CLOSE      =  1500;//3800;    // Ҫ����һ�µ�λ������0.01HZ
unsigned int OPEN_LOOP_TOR_START    =  1000;
unsigned int FRQ_PWM_SHIFT_EN       =  10000;   // Ҫ����һ�µ�λ������0.01HZ

unsigned int LowLimit               =  350;     // ������������ ���Ʊ�ϵ��
unsigned int HighLimit              =  700;    // ������������ ���Ʊ�ϵ��

#define SpinControlHZ                  5625              // ˳��������ֵ��, 0.01HZ
long SpinControlInternal   =  (long)SpinControlHZ << 4;  // ˳��������ֵ��, �ڲ���λ��OMG,must be long as pm_est_lpf_omg1 is long
unsigned int BemfOffset             = 150;//80;

///////////////////////////////////////////////////////////////////////////////////////
// Ƶ�ʺͼӼ��ٲ�������
///////////////////////////////////////////////////////////////////////////////////////
         int RefSet                 =  1000;   // 120.00HZ
//5ps-2500rpm-208hz
unsigned int ACC1                   =  2500;    // ���ٶμ���ʱ�� 5.0S
unsigned int ACC2                   =  2000;    // ���ٶμ���ʱ�� 2.0S
unsigned int DEC                    =  2000;    // ���ٶμ���ʱ�� 2.0S
unsigned int DCBrakeTime            =  10;      // ֱ���ƶ�ʱ��     1.0S

///////////////////////////////////////////////////////////////////////////////////////
// �ٶȻ���������
///////////////////////////////////////////////////////////////////////////////////////
volatile unsigned int F_CHANGING_POINT_1_PI  =  1000;
volatile unsigned int F_CHANGING_POINT_2_PI  =  2000;
volatile unsigned int LOW_SPEED_KI           =  20;
volatile unsigned int LOW_SPEED_KP           =  20;
volatile unsigned int HIGH_SPEED_KI_GAIN     =  10;
volatile unsigned int HIGH_SPEED_KP_GAIN     =  10;


///////////////////////////////////////////////////////////////////////////////////////
// ����������������
///////////////////////////////////////////////////////////////////////////////////////
volatile unsigned int D_CUR_KI               =  50;
volatile unsigned int D_CUR_KP               =  50;
volatile unsigned int Q_CUR_KI               =  50;
volatile unsigned int Q_CUR_KP               =  50;

///////////////////////////////////////////////////////////////////////////////////////
// ���Ʋ�������
///////////////////////////////////////////////////////////////////////////////////////
unsigned int PWM_FREQUENCY          =  160;     // 100 * 0.1kHz �ز�Ƶ��
unsigned int AVR_MODE               =  1;       // AVR. 0,1: Enable, 2:Disabled

//--------------------- Ƶ�ʷ�Χ����----------------------/
unsigned int MAX_LIMIT_FREQ         =  2100;   // 300.00Hz
unsigned int MOTOR_RATED_FRE        =  16000;
unsigned int COAST_STOP_FRQ         =  100;    // 1.0HZ,����ͣ����ʼƵ��

//--------------------- ֱ���ƶ�����----------------------/
unsigned int DC_CONTROL_KP          = 10;
unsigned int DC_CONTROL_KI          = 5;
unsigned int DC_BRAKE_CUR           = 3000;

//--------------------- �������ưٷֱȲ���-------------/
unsigned int TORQUE_CUR_LIMIT       = 160;//125;

//--------------------- ���Ų���----------------------/
unsigned int FILED_WEEKING_MODE     = 2;       // FE-00, 0 ~ 2
unsigned int FILED_WEEKING_CUR_SCAL = 80;      // FE-01, 0 ~ 200
unsigned int FILED_WEEKING_SCAL     = 4;       // FE-02, 1 ~ 10
unsigned int FIELD_WEAK_REF         = 3950;    // FE-05, 0 ~ 4100
unsigned int IPD_PERIOD_SCALING     = 128;     // ���������������ر�С�������е����ܴ�
unsigned int IdMaxScaling           = 512;     // ���ŵ���ռ�������ٷֱȣ�512 ����50%��Q10 ��ʽ
unsigned int IqMaxSet               = 400;     // NOT USED

unsigned int SOFT_OC_POINT          = 10000;   // Current limit : 3A,150%
                                               // 9000 * 5 / 4096 = 11A
unsigned int STALL_PR_TIME          = 8;       // 8s, 8000ms

unsigned int SF_LOW_SPEED            = 160;
unsigned int MIN_CUR_LOW_SPEED       = 30;

unsigned int OVER_SPEED_SCALING      = 130;


// #define  THETA_COM_0_1_DEGREE         20   // tmp_swDeltaThetaPu, 182 ~ 1.0Degree...
// 1000Hz, if Coff = 1000, tmp_swDeltaThetaPu = 620, that is 3.4Degree......
// For AC System, 250HZ Max,
// ThetaCoff    Degree
// 4000         3.4
// 10000        8.5
// 15000        12.7
unsigned int ThetaCoff              =  1;//5000;
unsigned int AUTO_RESET_CNT         =  5;


//--------------------- FOC �������Ʋ�����һ�㲻���޸ģ�----------------------/
unsigned int SPEED_FEEDBACK_FILTER   = 56;
unsigned int FILED_WEEKING_OUTVOL_SC = 0;
unsigned int SPECIAL_FACTOR_1        = 0;
unsigned int SPEED_MEASURE_PAR_1     = 20;
unsigned int SPEED_MEASURE_PAR_2     = 20;
unsigned int START_PRESET_CUR        = 0;
unsigned int LOW_LIMIT_FREQUENCY     = 0;
unsigned int INIT_POS_DECTION_MODE   = 1;
unsigned int INIT_POS_DECTION_CUR    = 120;
unsigned int INIT_POS_DECTION_TIME   = 60;
unsigned int LOW_SPEED_FILTER        = 16;
unsigned int PMSM_RS_MIN             = 16;

//--------------------- ���������  ����----------------------/
unsigned int T_DELAY                = 150; // 1.5us
unsigned int T_SAMPLE               = 150; // 1.5us
//#define  CURR_SAMPLE_DELAY         (T_SAMPLE - T_DELAY)
//#define  MIN_SAMPLE_TIME           (T_SAMPLE + T_DELAY)
//#define  TWO_MIN_SAMPLE_TIME       (MIN_SAMPLE_TIME*2)

unsigned int FirstSamplePointShift  = 100; // 1.0us
unsigned int SecondSamplePointShift = 100; // 1.0us

unsigned int RatioForLowNoisePWM            = 2000;
unsigned int RatiotThresholdForLowNoisePWM  = 250;

#define ID_MIN_FRQ                  0//5                                  // 5.0HZ.
#define ID_MAX_FRQ                  50                                 // 50.0Hz
unsigned long IdMinInternal =  (long)ID_MIN_FRQ * 1602;                        // 5 * 1602
unsigned long IdMaxInternal =  (long)ID_MAX_FRQ * 1602;                        // 50 * 1602

#define SF_INDEPAND_OF_FREQUENCY_MIN    20                             // 20HZ
#define SF_INDEPAND_OF_FREQUENCY_MAX    40                             // 40HZ
unsigned long LowFreqencyOFSF  =  (long)SF_INDEPAND_OF_FREQUENCY_MIN * 1602;                        // 20 * 1602
unsigned long HighFreqencyOFSF =  (long)SF_INDEPAND_OF_FREQUENCY_MAX * 1602;                        // 40 * 1602

#define SF_INDEPAND_OF_FREQUENCY_MIN    20                             // 20HZ
#define SF_INDEPAND_OF_FREQUENCY_MAX    40                             // 40HZ

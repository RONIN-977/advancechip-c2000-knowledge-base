
/************************************************************************
 Project:             Automotive water pumps
 Filename:            LDF.c
 Partner Filename:    N/A
 Description:         Partner file of LDF.h
 Complier:            Code Composer Studio for ADM32F036, CCS Systems.
 CPU TYPE :           ADM32F036A2
*************************************************************************
 Copyright (c) 2024 **** Co., Ltd.
 All rights reserved.
*************************************************************************
*************************************************************************
 Revising History (ECL of this file):

************************************************************************/

/************************************************************************
 Beginning of File, do not put anything above here except notes
 Compiler Directives
*************************************************************************/

#include "Define.h"
#include "Main.h"

///////////////////////////////////////////////////////////////////////////////////////
// ���ư��������
///////////////////////////////////////////////////////////////////////////////////////
unsigned int MAX_DC_VOL_3_3V      =  15030;       // 0.1vdc
#define  MAX_PEAK_CUR_3_3V           3333         // 0.01A
unsigned long MAX_PEAK_CUR_3_3V_410 =  ((long)MAX_PEAK_CUR_3_3V << 12) / 10;

unsigned int OVER_DC_VOL_POINT    =  7500;         // 0.1vdc
unsigned int OVER_DC_VOL_LIMIT    =  5800;         // 0.1vdc
unsigned int UNDER_DC_VOL_POINT   =  1000;            // 0.1vdc

#define DEAD_TIME                    150                                 // ����ʱ�䣬0.50US
#define DEAD_COMPENATION_TIME        50                                  // ��������ʱ�䣬0.25US
unsigned int DeadTimeInternal     =  ((long)DEAD_TIME * DSP_CLOCK) / 100;               // ����ʱ��
unsigned int DeadTimeCompInternal =  ((long)DEAD_COMPENATION_TIME * DSP_CLOCK) / 100;   // ��������ʱ��

#define HARDWARE_OVER_CUR            2000                                 // Ӳ�������Ƚ�ֵ��10.00A
#define HARDWARE_CBC_CUR             200                                 // CBC�����Ƚ�ֵ, 8.00A
unsigned int OverCurPointInternal =  ((long)HARDWARE_OVER_CUR << 9) / MAX_PEAK_CUR_3_3V + 512;   // Ӳ�������Ƚ�ֵ
unsigned int CBCCurPointInternal  =  ((long)HARDWARE_CBC_CUR  << 9) / MAX_PEAK_CUR_3_3V + 512;   // CBC�����Ƚ�ֵ

///////////////////////////////////////////////////////////////////////////////////////
// �����������
///////////////////////////////////////////////////////////////////////////////////////
unsigned int MOTOR_RATED_POWER  =  2000;    //0.1WΪ��λ
unsigned int MOTOR_RATED_VOL    =  424;
unsigned int MOTOR_RATED_CUR    =  100;
unsigned int LOWER_LIMIT_FREQ   =  0;
unsigned int COAST_STOP_FRQ     =  200;     // 1.0HZ,����ͣ����ʼƵ��

unsigned int PMSM_PN            =  4;          //������
unsigned int PMSM_LD            =  5478;       // 37uH
unsigned int PMSM_LQ            =  6180;       // 50uH
unsigned int PMSM_RS            =  1220;       // 11mohm   1.5
unsigned int PMS_L_R_UNIT       =  0;          //
unsigned int PMSM_KE            =  102;        // ke = 52v/kRpm

//unsigned int PMSM_LD            =  11920/2;       // 37uH
//unsigned int PMSM_LQ            =  21880/2;       // 50uH
//unsigned int PMSM_RS            =  1220;       // 11mohm
//unsigned int PMS_L_R_UNIT       =  0;          //
//unsigned int PMSM_KE            =  102;        // ke = 4

///////////////////////////////////////////////////////////////////////////////////////
// �����л��ջ���������
///////////////////////////////////////////////////////////////////////////////////////
unsigned int FRQ_OPEN_TO_CLOSE      =  1800;    // Ҫ����һ�µ�λ������0.01HZ
unsigned int OPEN_LOOP_TOR_START    =  1000;
unsigned int FRQ_PWM_SHIFT_EN       =  10000;   // Ҫ����һ�µ�λ������0.01HZ

unsigned int LowLimit               =  450;     // ������������ ���Ʊ�ϵ��
unsigned int HighLimit              =  1000;    // ������������ ���Ʊ�ϵ��

#define SpinControlHZ                  5625              // ˳��������ֵ��, 0.01HZ
long SpinControlInternal   =  (long)SpinControlHZ << 4;  // ˳��������ֵ��, �ڲ���λ��OMG,must be long as pm_est_lpf_omg1 is long

///////////////////////////////////////////////////////////////////////////////////////
// Ƶ�ʺͼӼ��ٲ�������
///////////////////////////////////////////////////////////////////////////////////////
         int RefSet                 =  3000;    // 120.00HZ
unsigned int ACC1                   =  50;      // ���ٶ�RPM/Min
unsigned int ACC2                   =  500;     // ���ٶ�RPM/Min
unsigned int DEC                    =  1000;    // ����RPM/Min
unsigned int DCBrakeTime            =  20;      // ֱ���ƶ�ʱ��  1.0S

///////////////////////////////////////////////////////////////////////////////////////
// �ٶȻ���������
///////////////////////////////////////////////////////////////////////////////////////
unsigned int F_CHANGING_POINT_1_PI  =  1000;
unsigned int F_CHANGING_POINT_2_PI  =  5000;
unsigned int LOW_SPEED_KI           =  20;
unsigned int LOW_SPEED_KP           =  20;
unsigned int HIGH_SPEED_KI_GAIN     =  10;
unsigned int HIGH_SPEED_KP_GAIN     =  15;


///////////////////////////////////////////////////////////////////////////////////////
// ����������������
///////////////////////////////////////////////////////////////////////////////////////
#ifdef ENABLE_NEW_STATIC_OBS
unsigned int D_CUR_KI               =  200;
unsigned int D_CUR_KP               =  400;
unsigned int Q_CUR_KI               =  200;
unsigned int Q_CUR_KP               =  220;
#else
unsigned int D_CUR_KI               =  50;
unsigned int D_CUR_KP               =  500;
unsigned int Q_CUR_KI               =  50;
unsigned int Q_CUR_KP               =  200;
#endif

///////////////////////////////////////////////////////////////////////////////////////
// ���Ʋ�������
///////////////////////////////////////////////////////////////////////////////////////
unsigned int PWM_FREQUENCY          =  120;     // 100 * 0.1kHz �ز�Ƶ��
unsigned int AVR_MODE               =  1;       // AVR. 0,1: Enable, 2:Disabled

//--------------------- Ƶ�ʷ�Χ����----------------------/
unsigned int MAX_LIMIT_FREQ         =  56600;   // 400.00Hz
unsigned int MOTOR_RATED_FRE        =  56600;

//--------------------- ֱ���ƶ�����----------------------/
unsigned int DC_CONTROL_KP          = 3;
unsigned int DC_CONTROL_KI          = 5;
unsigned int DC_BRAKE_CUR           = 3100;

//--------------------- �������ưٷֱȲ���-------------/
unsigned int TORQUE_CUR_LIMIT       = 1000;    // 180.0%

//--------------------- ���Ų���----------------------/
unsigned int FILED_WEEKING_MODE     = 1;       // FE-00, 0 ~ 2
unsigned int FILED_WEEKING_CUR_SCAL = 80;      // FE-01, 0 ~ 200
unsigned int FILED_WEEKING_SCAL     = 4;       // FE-02, 1 ~ 10
unsigned int FIELD_WEAK_REF         = 3950;    // FE-05, 0 ~ 4100
unsigned int IPD_PERIOD_SCALING     = 128;     // ���������������ر�С�������е����ܴ�
unsigned int IdMaxScaling           = 400;     // ���ŵ���ռ�������ٷֱȣ�512 ����50%��Q10 ��ʽ

unsigned int SOFT_OC_POINT          = 10000;   // Current limit : 10000 / 4096 = 250%
                                               // 9000 * 5 / 4096 = 11A
unsigned int STALL_PR_TIME          = 8;       // 8s, 8000ms

unsigned int SF_LOW_SPEED            = 160;
unsigned int MIN_CUR_LOW_SPEED       = 20;

unsigned int OVER_SPEED_SCALING      = 130;

//--------------------- FOC �������Ʋ���-----------------/
unsigned int SPEED_FEEDBACK_FILTER   = 56;
unsigned int FILED_WEEKING_OUTVOL_SC = 0;
unsigned int SPECIAL_FACTOR_1        = 0;
unsigned int SPEED_MEASURE_PAR_1     = 20;
unsigned int SPEED_MEASURE_PAR_2     = 20;
unsigned int START_PRESET_CUR        = 0;
unsigned int LOW_LIMIT_FREQUENCY     = 0;
unsigned int INIT_POS_DECTION_MODE   = 1;
unsigned int INIT_POS_DECTION_CUR    = 120;
unsigned int INIT_POS_DECTION_TIME   = 60;
unsigned int LOW_SPEED_FILTER        = 16;
unsigned int PMSM_RS_MIN             = 16;

//--------------------- SVPWM��ص���  ����----------------------/
// �����ʽʹ��û�����Σ���Ƶ�ʴ�С���趨ֵ�����л���
unsigned int FIVEPWM_FRQ_SET         = 40000;       // 100.00Hz
unsigned int DPWM_FRQ_LEVEL          = 100;         // 5.00Hz

// һ�����������㷨��Ĭ�Ϲرա���Ҫʱ����������ʱ��Ҫ�ܿ�
unsigned int RandomSezeorVectorModeEn= 0;           // 0:��ֹ
unsigned int RandomZero_FRQ_SET      = 10000;       // 100HZ

// ��С��ʸ�����ơ�ע�⣺
// Zero_Length_Min -- Ӧ���ڷ��ȵ����Լ�С��Zero_Length_Min2 ���������Сֵ���ơ�
// һ�㽨�飺
// ˫���裺Zero_Length_Min         = 0
//        Zero_Length_Min2        = 120;
// �����裺Zero_Length_Min         = 0
//        Zero_Length_Min2        = 0;
unsigned int Zero_Length_Min         = 0;
unsigned int Zero_Length_Min2        = 200;

//--------------------- ���������  ����----------------------/
unsigned int T_DELAY                = 150; // 1.5us
unsigned int T_SAMPLE               = 150; // 1.5us
//#define  CURR_SAMPLE_DELAY         (T_SAMPLE - T_DELAY)
//#define  MIN_SAMPLE_TIME           (T_SAMPLE + T_DELAY)
//#define  TWO_MIN_SAMPLE_TIME       (MIN_SAMPLE_TIME*2)

unsigned int FirstSamplePointShift  = 100; // 1.0us
unsigned int SecondSamplePointShift = 100; // 1.0us

// #define  THETA_COM_0_1_DEGREE         20   // tmp_swDeltaThetaPu, 182 ~ 1.0Degree...
// 1000Hz, if Coff = 1000, tmp_swDeltaThetaPu = 620, that is 3.4Degree......
// For AC System, 250HZ Max,
// ThetaCoff    Degree
// 4000         3.4
// 10000        8.5
// 15000        12.7
unsigned int ThetaCoff              =  25000;//5000 15000 20000
unsigned int AUTO_RESET_CNT         =  5;
unsigned int AVR_Mode               =  AVR_MODE_DEFAULT_1;

// TS_L_VDC
// 100MHZ, CLKDIV = 7, TS_L_VDC * 128 * 1 / 100MHZ = 75... ... ... ...
// Toggle EPWMxA Output: at Period time, so 75 * 2 = 150US ... ... ...
// U = L*I/T, SO I = U*T/(Ld+Lq) = 310.0V * 0.150 / 40MH = 1.2A... ...
// T = ((l_ld + l_lq) * gMotorInfo.Current) / gUDC.uDCFilter = 40000 * 20 / 3100 = 258
// 258 * 60 / 150 = 100
///////////////////////////////////////////////////////////////////////
unsigned int TS_L_VDC_SCALING       =  1024;

// BYD.PUMB:
// WITH KP_D = 300, KP_Q = 400, KI = 200
// Then Alfa            : 500 ~ 5000 OK
//      LamdaValueForOBS: 0   ~ 10
//      set to 2 as with high eff
unsigned int AlfaValueForOBS        = 3000;         // Alfa: 1000 ~ 3000
unsigned int LamdaValueForOBS       = 10;           // Lamda:0 ~ 16
unsigned int FilterCntLowForOBS     = 8;            // LOW:  8
unsigned int FilterCntHighForOBS    = 6;            // High: 8

#define ID_MIN_FRQ                  5                                  // 5.0HZ.
#define ID_MAX_FRQ                  50                                 // 50.0Hz
unsigned long IdMinInternal =  (long)ID_MIN_FRQ * 1602;                        // 5 * 1602
unsigned long IdMaxInternal =  (long)ID_MAX_FRQ * 1602;                        // 50 * 1602

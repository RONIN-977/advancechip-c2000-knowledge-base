# FIXED

Main/HardwareSetup.obj: ../Main/HardwareSetup.c
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm_defines.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/MotorInclude.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/MainInclude.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Define.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/SubPrgInclude.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/CANcomm.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/SPIcomm.h
Main/HardwareSetup.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Parameter.h

../Main/HardwareSetup.c:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm_defines.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/MotorInclude.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/MainInclude.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Define.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/SubPrgInclude.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/CANcomm.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/SPIcomm.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Parameter.h:


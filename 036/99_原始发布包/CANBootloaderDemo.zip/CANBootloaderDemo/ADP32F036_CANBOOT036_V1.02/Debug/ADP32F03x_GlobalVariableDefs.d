# FIXED

ADP32F03x_GlobalVariableDefs.obj: ../ADP32F03x_GlobalVariableDefs.c
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
ADP32F03x_GlobalVariableDefs.obj: C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h

../ADP32F03x_GlobalVariableDefs.c: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h: 
C:/Users/50730/workspace_v8/Test/Comments_Confirm/ADP32F036_CANBOOT036_V1.01/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h: 

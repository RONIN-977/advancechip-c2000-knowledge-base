# 0039 CAN 升级客户初始化适配说明
本次直接修改 APP_CAN_ONLY，使升级模块复用客户 CAN 和定时器初始化。代码已按客户提供的初始化片段调整；邮箱号、客户时基和安全停机接口留有明确待填写点。当前为初步移植，未编译、未上板，不作为可烧录固件。

## 本次修改范围

原 APP、BOOT 以及 Desktop\kuobo 下的客户文件保持不变。APP_CAN_ONLY 修改前已完整压缩备份，备份 ZIP 位于它的同级目录。旧版编译产物与 PASS 记录已归档到验证记录目录，不能证明本次代码可运行。

| 文件 | 已经修改的内容 |
| src/main.c | 改为客户系统初始化、业务后台任务及升级调用模板；移除 LED 和示例心跳。 |
| src/boot_io.c | 删除示例 CAN 模块初始化及 Timer 初始化；新增升级消息对象配置，时基改接客户接口。 |
| src/upgrade_entry.c | 只初始化协议状态；对象号改用宏；有效请求后增加客户安全停机接口。 |
| include/board_config.h | 引脚参数改为 GPIO12 RX、GPIO13 TX；速率暂记 250k；新增待填消息对象号及编译提示。 |
| include/customer_upgrade_port.h | 新增客户系统、后台任务、毫秒计数和安全停机接口声明。 |
| include/boot_io.h 和 upgrade_entry.h | 更新初始化接口及调用要求。 |
| application.cmd | 新增 K10 注释，提示客户链接分区整合；未改原示例内存布局。 |

boot_core.c 和 boot_core.h 与修改前备份逐字节一致。协议校验、CAN 分片格式、请求标记值和复位流程未改变。代码中的 K01 至 K10 标记用于查找后续调整位置。

# 初始化与主循环接入
## 客户 main 中的调用顺序

```text
客户原系统初始化（PLL、GPIO、CAN、定时器、中断）
    ↓
客户 CAN_Config_Init() 完成
    ↓
boot_can_objects_init();
upgrade_entry_init();
    ↓
while (1) 中执行客户后台任务及 upgrade_entry_poll();
```

当前 main.c 用 Customer_SystemInit() 包装客户初始化，并用 Customer_BackgroundTask() 表示客户后台任务。这两个接口尚未实现。正式合并时可以直接沿用客户原 main 和原调用顺序，仅加入两处升级初始化与循环内轮询，不必复制模板 main.c。

## 不再照搬的初始化

upgrade_entry_init() 不再调用 boot_ports_init()、boot_timers_init()，只保留 bl_init() 和 bl_can_reset()。boot_io.c 不再复位 CAN、不改波特率或引脚、不重配 Timer0/1/2。客户的 InitPeriherals()、init_eCAN_A()、InitCpuTimer() 和中断注册继续使用原实现。

## 消息对象配置位置

boot_can_objects_init() 只创建升级 RX/TX 对象，必须在客户 CAN_Config_Init() 之后执行。之后若业务重新调用 CAN_initModule() 或改写这些对象，将破坏升级通道。若客户把对象配置统一管理，也可将两段 CAN_setupMessageObject 合并进 CAN_Config_Init，只保留一次配置。

## 保留两种写法

客户寄存器代码和升级 driverlib 调用可以并存。需核对目标器件头文件、库版本、寄存器地址和时钟配置相互一致；无需仅为统一风格重写客户初始化。当前 APP 接收仍是轮询方式，不新增 CAN 接收中断。

# 后续调整位置
| 标记 | 定位与后续操作 |
| K01 | board_config.h：暂记 BOOT_CAN_BAUD=250000。确认客户实际速率后更新记录并同步 BOOT、上位机；该宏不会改变客户 APP 的寄存器配置。 |
| K02 | board_config.h：BOOT_CAN_RX_OBJ 和 BOOT_CAN_TX_OBJ 目前均为 0。填入客户未使用、互不相同的对象号 1 至 32；接收、发送和 TX 完成掩码会自动跟随宏。未填时 #error 提示，不要仅删提示。 |
| K03 | 客户 PLL、CAN 时钟及 vendor/device/device.h：核对真实 CPU/CAN 时钟，延时常量要匹配。 |
| K04 | main.c 和 customer_upgrade_port.h：接入客户原系统初始化及后台任务。正式合并原 main 时可取消这两个模板包装调用。 |
| K05 | customer_upgrade_port.h、boot_io.c 的 boot_millis：实现 Customer_GetMillis。返回 uint32_t 毫秒计数，发送等待期间也必须继续更新。 |
| K06 | customer_upgrade_port.h、upgrade_entry.c 的 dispatch：实现 Customer_PrepareForUpgrade；完成安全停机并锁住重新启动才返回 1。 |
| K07 | boot_io.c 的 boot_can_objects_init：确认对象不冲突、标准帧过滤和升级 ID。当前请求 0x601、应答 0x581。 |
| K08 | upgrade_entry.c 的 upgrade_entry_init：只初始化协议状态，在客户设备与升级对象初始化后调用一次。 |
| K09 | upgrade_entry.c 的 upgrade_entry_poll：确认客户 ISR 或统一收帧程序不会抢读升级 RX 对象；必要时改接客户收帧队列。 |
| K10 | application.cmd 和配套 BOOT：整合应用入口、Flash 范围和 RAM 标记预留，保留客户控制算法、CLA、DMA 等段。 |

修改对象号后，初始化、CAN_readMessageWithID、CAN_sendMessage_updateDLC 和 TX 请求掩码均使用同一组宏，无需分别寻找硬编码 1、2。

# 时基与配套验证
## 客户时基接入

客户 Timer0/Timer1 的 TPR、TPRH 为 0，不能使用旧版按 Timer0 为 1MHz 换算的 boot_millis。本次已改为返回 Customer_GetMillis()。优先复用客户现有中断维护的毫秒计数，并确保读取一致。若用硬件 Timer 差值换算，按真实输入时钟累计并保留余数，不直接对当前计数值除法后当成单调毫秒数。

can_wait_tx() 的等待上限仍为 500ms。毫秒数不能只在后台主循环中自增，否则进入发送等待后时间停止，超时判断无法退出。客户若改接 TX 队列，应在最后一帧真正发送完成后才返回成功，不能把入队成功当成发送完成。

## 时钟与 CAN 引脚

客户 init_eCAN_A(40,5,4,1,2,1) 选择系统时钟作为 CAN 输入。按配置计算，速率为 fCAN/[40×(1+5+4)]：100MHz 对应 250k，120MHz 对应 300k。客户目录没有 PLL 配置，250k 尚待核实。GPIO12 RX、GPIO13 TX 已写入参数；客户 CAN RX 异步采样设置仍需确认，必要时在客户 GPIO 配置中补 GPAQSEL1.bit.GPIO12=3。

## 安全停机和复位

dispatch 先检查有效请求及 BL_OK，再调用 Customer_PrepareForUpgrade。返回 0 时不发成功 ACK、不写标记、不复位，主机需重发请求；返回 1 后完成 CAN 应答再写标记并 watchdog reset。客户停机实现应确认 PWM、驱动使能和相关执行器已安全，并阻止后台或控制 ISR 再次启机。

## BOOT 和链接文件

本次没有修改 BOOT。配套 BOOT 必须使用客户板 GPIO12/13、确认后的速率和相同升级 ID。客户 APP 入口应为 0x090000，Flash 使用范围为 [0x090000,0x0AF000)，按该配套 BOOT 整合；预留 RAM 字地址 0x3F8 至 0x3FB，启动、自检和数据段不得提前覆盖。

## 继续完成移植所需材料

补充 CAN_Config_Init、CAN 收发处理、PLL 与时钟配置、客户毫秒时基和停机状态机。然后填写对象号与接口、整合客户链接文件，再进行编译和上板验证。当前只做源码结构核对及原文件完整性检查，没有执行 CCS 编译、烧录或实板 CAN 升级测试。

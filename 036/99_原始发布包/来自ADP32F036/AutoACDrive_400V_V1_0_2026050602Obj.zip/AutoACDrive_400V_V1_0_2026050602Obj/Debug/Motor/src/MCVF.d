# FIXED

Motor/src/MCVF.obj: ../Motor/src/MCVF.c
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/MotorInclude.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/MainInclude.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Define.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/SubPrgInclude.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Parameter.h
Motor/src/MCVF.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Record.h

../Motor/src/MCVF.c:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/MotorInclude.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/MainInclude.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Define.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/SubPrgInclude.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Parameter.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Record.h:


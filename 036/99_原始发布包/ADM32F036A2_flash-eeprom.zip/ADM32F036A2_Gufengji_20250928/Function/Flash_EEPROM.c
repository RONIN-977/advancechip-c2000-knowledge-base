/*
 * Flash_eeprom.c
 *
 *  Created on: 2025��8��14��
 *      Author: Advancechip
 */
#include "Main.h"
#include "RunSrc.h"
#include "Define.h"
#include "Reference.h"
#include "FuncUser.h"
#include "MotorInclude.h"
#include "Parameter.h"
#include "LinLDF.h"
#include "DSP2803x_GlobalPrototypes.h"
#include "Flash_ADP32F03x_API_Library.h"
#include "Flash_ADP32F03x_API_Config.h"
#include "Flash_EEPROM.h"

FLASH_ST FlashStatus;
/*******************************************************************************
* Function Name  :Flash_EEPROM_Init
* Description    : ��ʼ������
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Flash_EEPROM_Init(void)
{
    EALLOW;
    Flash_CPUScaleFactor = SCALE_FACTOR;
    Flash_CallbackPtr = 0;
    EDIS;
}

/*******************************************************************************
* Function Name  : Flash_EEPROM_Read
* Description    : ��ȡ����,��ȡ�̶�һλ�����ݵ�ַ,355ns@100MHz
* Input          : ���ݵ�ַ
* Output         : None
* Return         : ��������
*******************************************************************************/
Uint16 Flash_EEPROM_ReadWord(Uint16 *FlashAddr)
{
    return *FlashAddr;  // ֱ�Ӷ�ȡ�ڴ�ӳ���Flash
}

/*******************************************************************************
* Function Name  :Flash_EEPROM_Erase_OneWord
* Description    : ���ֲ������� (���Ĺ���) 6.2ms@100MHz
* Input          : ���ݵ�ַ
* Output         : None
* Return         : ����״̬
*******************************************************************************/
#pragma CODE_SECTION(Flash_EEPROM_Erase_OneWord,"ramfuncs");
Uint16 Flash_EEPROM_Erase_OneWord(Uint16 *Addr)
{
    Uint16 Status;
    Uint32 offset_Len;
    Uint32 offset;
    Uint16 buffer[EEPROM_SIZE];// �������ݻ�����

    // ��֤��ַ��EEPROM��Χ��
    if ((Uint32)Addr < (Uint32)EEPROM_START ||
        (Uint32)Addr >= (Uint32)(EEPROM_START + EEPROM_SIZE)) {
        return STATUS_FAIL;
    }

    //ϵͳ��ͣ
    DisableDog();
    DINT;
    DRTM;
    Status = CsmUnlock();
    if (Status != STATUS_SUCCESS) {
        //ϵͳ�ָ�
        EINT;
        ERTM;
        KickDog();
        EnableDog();
        return STATUS_FAIL;
    }

    // --- ����1: ��������EEPROM��SRAM������ ---
    for (offset = 0; offset < EEPROM_SIZE; offset++) {
        buffer[offset] = *(EEPROM_START + offset);
    }

    // --- ����2: ����Ŀ������EEPROM ---
    Status = Flash_Erase(EEPROM_ALL, &FlashStatus);
    if (Status != STATUS_SUCCESS)
    {
        //ϵͳ�ָ�
        EINT;
        ERTM;
        KickDog();
        EnableDog();
        return STATUS_FAIL;
    }

    // --- ����3: ����Ҫ�����Ĺ̶������⽫��������д��EEPROM ---
    if(Addr == EEPROM_START)
    {
        //����һλ����������λ
        Status = Flash_Program(EEPROM_START+1, &buffer[1], EEPROM_SIZE-1, &FlashStatus);
        if (Status != STATUS_SUCCESS)
        {
            //ϵͳ�ָ�
            EINT;
            ERTM;
            KickDog();
            EnableDog();
            return STATUS_FAIL;
        }
    }
    else if(Addr == EEPROM_START + EEPROM_SIZE - 1)
    {
        //�����һλ����������λ
        Status = Flash_Program(EEPROM_START, &buffer[0], EEPROM_SIZE-1, &FlashStatus);
        if (Status != STATUS_SUCCESS)
        {
            //ϵͳ�ָ�
            EINT;
            ERTM;
            KickDog();
            EnableDog();
            return STATUS_FAIL;
        }
    }
    else
    {
        //�����м�λ�Ļ�����ǰ����������
        offset_Len = Addr - EEPROM_START; //��ַƫ�Ƴ���
        //����һ������λ��Ϊ0xFFFF��һ����д��Flash ������1��2��ִ��ʱ��һ��
        //buffer[offset_Len] = 0xFFFF;
        //Status = Flash_Program(EEPROM_START, &buffer[0], EEPROM_SIZE, &FlashStatus);
        //if (Status != STATUS_SUCCESS) return STATUS_FAIL;

        //��������������λ�⣬������ǰ������д��Flash
        Status = Flash_Program(EEPROM_START, &buffer[0], offset_Len, &FlashStatus);
        if (Status != STATUS_SUCCESS)
        {
            //ϵͳ�ָ�
            EINT;
            ERTM;
            KickDog();
            EnableDog();
            return STATUS_FAIL;
        }
        Status = Flash_Program(Addr+1, &buffer[offset_Len + 1], EEPROM_SIZE - offset_Len -1, &FlashStatus);
        if (Status != STATUS_SUCCESS)
        {
            //ϵͳ�ָ�
            EINT;
            ERTM;
            KickDog();
            EnableDog();
            return STATUS_FAIL;
        }
    }

    //ϵͳ�ָ�
    EINT;
    ERTM;
    KickDog();
    EnableDog();

    return STATUS_SUCCESS;
}

/*******************************************************************************
* Function Name  : Flash_EEPROM_WriteWord
* Description    : д�뺯�� 0ne Word 120us@100MHz ;  128Word 1ms@100MHz
* Input          : ���ݵ�ַ���������ݡ����ݳ���
* Output         : None
* Return         : д��״̬
*******************************************************************************/
#pragma CODE_SECTION(Flash_EEPROM_WriteWord,"ramfuncs");
Uint16 Flash_EEPROM_WriteWord(Uint16 *FlashAddr, Uint16 *DataBuf, Uint32 Length)
{
    Uint16 Status;

    // ��֤��ַ��EEPROM��Χ��
    if ((Uint32)FlashAddr < (Uint32)EEPROM_START ||
        (Uint32)FlashAddr >= (Uint32)(EEPROM_START + EEPROM_SIZE)) {
        return STATUS_FAIL;
    }

    //ϵͳ��ͣ
    DisableDog();
    DINT;
    DRTM;
    Status = CsmUnlock();
    if(Status != STATUS_SUCCESS)
    {
        EINT;
        ERTM;
        KickDog();
        EnableDog();
        return STATUS_FAIL;
    }
    Status = Flash_Program(FlashAddr, DataBuf, Length, &FlashStatus);
    if(Status != STATUS_SUCCESS)
    {
        EINT;
        ERTM;
        KickDog();
        EnableDog();
        return STATUS_FAIL;
    }
    EINT;
    ERTM;
    KickDog();
    EnableDog();
    return STATUS_SUCCESS;
}

/*******************************************************************************
* Function Name  : Flash_EEPROM_EraseAll
* Description    : ��������  1KWord 5.2ms@100MHz
* Input          : ����
* Output         : None
* Return         : д��״̬
*******************************************************************************/
#pragma CODE_SECTION(Flash_EEPROM_EraseAll,"ramfuncs");
Uint16 Flash_EEPROM_EraseAll(Uint16 SectorMask)
{
    Uint16 Status;
    // ��֤��ַ��EEPROM��Χ��
    if (SectorMask != EEPROM_ALL) {
        return STATUS_FAIL;
    }

    DisableDog();
    DINT;
    DRTM;
    Status = CsmUnlock();
    if(Status != STATUS_SUCCESS)
    {
        EINT;
        ERTM;
        KickDog();
        EnableDog();
        return STATUS_FAIL;
    }
    Status = Flash_Erase(SectorMask, &FlashStatus);
    if(Status != STATUS_SUCCESS)
    {
        EINT;
        ERTM;
        KickDog();
        EnableDog();
        return STATUS_FAIL;
    }
    EINT;
    ERTM;
    KickDog();
    EnableDog();

    return STATUS_SUCCESS;
}


Uint16 CsmUnlock()
{
    volatile Uint16 temp;

    // Load the key registers with the current password. The 0xFFFF's are dummy
    // passwords.  User should replace them with the correct password for the DSP.

    EALLOW;
    CsmRegs.KEY0 = 0xFFFF;
    CsmRegs.KEY1 = 0xFFFF;
    CsmRegs.KEY2 = 0xFFFF;
    CsmRegs.KEY3 = 0xFFFF;
    CsmRegs.KEY4 = 0xFFFF;
    CsmRegs.KEY5 = 0xFFFF;
    CsmRegs.KEY6 = 0xFFFF;
    CsmRegs.KEY7 = 0xFFFF;
    EDIS;

    // Perform a dummy read of the password locations
    // if they match the key values, the CSM will unlock

    temp = CsmPwl.PSWD0;
    temp = CsmPwl.PSWD1;
    temp = CsmPwl.PSWD2;
    temp = CsmPwl.PSWD3;
    temp = CsmPwl.PSWD4;
    temp = CsmPwl.PSWD5;
    temp = CsmPwl.PSWD6;
    temp = CsmPwl.PSWD7;

    // If the CSM unlocked, return succes, otherwise return
    // failure.
    if (CsmRegs.CSMSCR.bit.SECURE == 0) return STATUS_SUCCESS;
    else return STATUS_FAIL;
}


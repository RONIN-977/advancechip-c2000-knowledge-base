# FIXED

Function/Parameter.obj: ../Function/Parameter.c
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Define.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Main.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Device.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Adc.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_BootVars.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_DevEmu.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Cla.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Comp.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_CpuTimers.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_ECan.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_ECap.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_EPwm.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_EQep.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Gpio.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_I2c.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Lin.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_NmiIntrupt.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PieCtrl.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PieVect.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Spi.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Sci.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_SysCtrl.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_XIntrupt.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PgaOpa.h
Function/Parameter.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Interface.h

../Function/Parameter.c: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Define.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Main.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Device.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Adc.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_BootVars.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_DevEmu.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Cla.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Comp.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_CpuTimers.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_ECan.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_ECap.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_EPwm.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_EQep.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Gpio.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_I2c.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Lin.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_NmiIntrupt.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PieCtrl.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PieVect.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Spi.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Sci.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_SysCtrl.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_XIntrupt.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PgaOpa.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Interface.h: 

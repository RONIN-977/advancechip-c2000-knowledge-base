//###########################################################################
//
// FILE:    DSP2803x_DefaultIsr.h
//
// TITLE:   DSP2803x Devices Default Interrupt Service Routines Definitions.
//
//###########################################################################
// $TI Release: $
// $Release Date: $
// $Copyright:
// Copyright (C) 2009-2025 Texas Instruments Incorporated - http://www.ti.com/
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//###########################################################################

#ifndef DSP2803x_DEFAULT_ISR_H
#define DSP2803x_DEFAULT_ISR_H

#ifdef __cplusplus
extern "C" {
#endif

//
// Default Interrupt Service Routine Declarations:
//
// The following function prototypes are for the
// default ISR routines used with the default PIE vector table.
// This default vector table is found in the DSP2803x_PieVect.h
// file.
//

//
// Non-Peripheral Interrupts
//
__interrupt void INT13_ISR(void);     // CPU-Timer 1
__interrupt void INT14_ISR(void);     // CPU-Timer 2
__interrupt void DATALOG_ISR(void);   // Datalogging interrupt
__interrupt void RTOSINT_ISR(void);   // RTOS interrupt
__interrupt void EMUINT_ISR(void);    // Emulation interrupt
__interrupt void NMI_ISR(void);       // Non-maskable interrupt
__interrupt void ILLEGAL_ISR(void);   // Illegal operation TRAP
__interrupt void USER1_ISR(void);     // User Defined trap 1
__interrupt void USER2_ISR(void);     // User Defined trap 2
__interrupt void USER3_ISR(void);     // User Defined trap 3
__interrupt void USER4_ISR(void);     // User Defined trap 4
__interrupt void USER5_ISR(void);     // User Defined trap 5
__interrupt void USER6_ISR(void);     // User Defined trap 6
__interrupt void USER7_ISR(void);     // User Defined trap 7
__interrupt void USER8_ISR(void);     // User Defined trap 8
__interrupt void USER9_ISR(void);     // User Defined trap 9
__interrupt void USER10_ISR(void);    // User Defined trap 10
__interrupt void USER11_ISR(void);    // User Defined trap 11
__interrupt void USER12_ISR(void);    // User Defined trap 12

//
// Group 1 PIE Interrupt Service Routines
//
__interrupt void  ADCINT1_ISR(void);   // ADC INT1 ISR - 1.1 OR 10.1
__interrupt void  ADCINT2_ISR(void);   // ADC INT2 ISR - 1.2 OR 10.2
__interrupt void  XINT1_ISR(void);     // External interrupt 1
__interrupt void  XINT2_ISR(void);     // External interrupt 2
__interrupt void  ADCINT9_ISR(void);   // ADC INT9 ISR
__interrupt void  TINT0_ISR(void);     // Timer 0
__interrupt void  WAKEINT_ISR(void);   // WD

//
// Group 2 PIE Interrupt Service Routines
//
__interrupt void EPWM1_TZINT_ISR(void);    // EPWM-1
__interrupt void EPWM2_TZINT_ISR(void);    // EPWM-2
__interrupt void EPWM3_TZINT_ISR(void);    // EPWM-3
__interrupt void EPWM4_TZINT_ISR(void);    // EPWM-4
__interrupt void EPWM5_TZINT_ISR(void);    // EPWM-5
__interrupt void EPWM6_TZINT_ISR(void);    // EPWM-6
__interrupt void EPWM7_TZINT_ISR(void);    // EPWM-7

//
// Group 3 PIE Interrupt Service Routines
//
__interrupt void EPWM1_INT_ISR(void);      // EPWM-1
__interrupt void EPWM2_INT_ISR(void);      // EPWM-2
__interrupt void EPWM3_INT_ISR(void);      // EPWM-3
__interrupt void EPWM4_INT_ISR(void);      // EPWM-4
__interrupt void EPWM5_INT_ISR(void);      // EPWM-5
__interrupt void EPWM6_INT_ISR(void);      // EPWM-6
__interrupt void EPWM7_INT_ISR(void);      // EPWM-7

//
// Group 4 PIE Interrupt Service Routines
//
__interrupt void ECAP1_INT_ISR(void);      // ECAP-1
__interrupt void HRCAP1_INT_ISR(void);     // HRCAP-1
__interrupt void HRCAP2_INT_ISR(void);     // HRCAP-2

//
// Group 5 PIE Interrupt Service Routines
//
__interrupt void EQEP1_INT_ISR(void);      // EQEP-1

//
// Group 6 PIE Interrupt Service Routines
//
__interrupt void SPIRXINTA_ISR(void);      // SPI-A
__interrupt void SPITXINTA_ISR(void);      // SPI-A
__interrupt void SPIRXINTB_ISR(void);      // SPI-B
__interrupt void SPITXINTB_ISR(void);      // SPI-B

//
// Group 7 PIE Interrupt Service Routines
//

//
// Group 8 PIE Interrupt Service Routines
//
__interrupt void I2CINT1A_ISR(void);       // I2C-A
__interrupt void I2CINT2A_ISR(void);       // I2C-A

//
// Group 9 PIE Interrupt Service Routines
//
__interrupt void SCIRXINTA_ISR(void);      // SCI-A
__interrupt void SCITXINTA_ISR(void);      // SCI-A
__interrupt void LIN0INTA_ISR (void);      // LIN-A
__interrupt void LIN1INTA_ISR (void);      // LIN-A
__interrupt void ECAN0INTA_ISR(void);      // eCAN-A
__interrupt void ECAN1INTA_ISR(void);      // eCAN-A

//
// Group 10 PIE Interrupt Service Routines:
//
// ADC INT1 ISR - 1.1 or 10.1
// ADC INT2 ISR - 1.2 or 10.2
__interrupt void ADCINT3_ISR(void);        // ADC INT3 ISR
__interrupt void ADCINT4_ISR(void);        // ADC INT4 ISR
__interrupt void ADCINT5_ISR(void);        // ADC INT5 ISR
__interrupt void ADCINT6_ISR(void);        // ADC INT6 ISR
__interrupt void ADCINT7_ISR(void);        // ADC INT7 ISR
__interrupt void ADCINT8_ISR(void);        // ADC INT8 ISR

//
// Group 11 PIE Interrupt Service Routines:
//
__interrupt void CLA1_INT1_ISR(void);      // CLA1 INT1 ISR
__interrupt void CLA1_INT2_ISR(void);      // CLA1 INT2 ISR
__interrupt void CLA1_INT3_ISR(void);      // CLA1 INT3 ISR
__interrupt void CLA1_INT4_ISR(void);      // CLA1 INT4 ISR
__interrupt void CLA1_INT5_ISR(void);      // CLA1 INT5 ISR
__interrupt void CLA1_INT6_ISR(void);      // CLA1 INT6 ISR
__interrupt void CLA1_INT7_ISR(void);      // CLA1 INT7 ISR
__interrupt void CLA1_INT8_ISR(void);      // CLA1 INT8 ISR

//
// Group 12 PIE Interrupt Service Routines:
//
__interrupt void XINT3_ISR (void);         // External interrupt 3
__interrupt void LVF_ISR(void);            // Latched overflow flag
__interrupt void LUF_ISR(void);            // Latched underflow flag

//
// Catch-all for Reserved Locations For testing purposes:
//
__interrupt void PIE_RESERVED(void);       // Reserved for test
__interrupt void rsvd_ISR(void);           // for test
__interrupt void INT_NOTUSED_ISR(void);    // for unused interrupts

#ifdef __cplusplus
}
#endif /* extern "C" */

#endif    // end of DSP2803x_DEFAULT_ISR_H definition

//
// End of file
//



/************************************************************************
 Project:             Automotive water pumps
 Filename:            LDF.c
 Partner Filename:    N/A
 Description:         Partner file of LDF.h
 Complier:            Code Composer Studio for ADM32F036, CCS Systems.
 CPU TYPE :           ADM32F036A2
*************************************************************************
 Copyright (c) 2024 **** Co., Ltd.
 All rights reserved.
*************************************************************************
*************************************************************************
 Revising History (ECL of this file):

************************************************************************/

/************************************************************************
 Beginning of File, do not put anything above here except notes
 Compiler Directives
*************************************************************************/

#include "Define.h"
#include "Main.h"

///////////////////////////////////////////////////////////////////////////////////////
// ���ư��������
///////////////////////////////////////////////////////////////////////////////////////
unsigned int MAX_PEAK_CUR_3_3V  = 2000;//4000;        // 0.01A
unsigned int MAX_DC_VOL_3_3V    =  480;         // 0.1vdc

unsigned int OVER_DC_VOL_POINT    =  160;         // 0.1vdc
unsigned int OVER_DC_VOL_LIMIT    =  150;         // 0.1vdc
unsigned int UNDER_DC_VOL_POINT   =  85;//75;     // 0.1vdc

///////////////////////////////////////////////////////////////////////////////////////
// �����������
///////////////////////////////////////////////////////////////////////////////////////
unsigned int MOTOR_RATED_POWER  =  2000;    //0.1WΪ��λ
unsigned int MOTOR_RATED_VOL    =  8;
unsigned int MOTOR_RATED_CUR    =  50;
unsigned int LOWER_LIMIT_FREQ   =  0;

unsigned int PMSM_LD            =  170;//150;//260;//120;//30;//432;          // 37uH
unsigned int PMSM_LQ            =  200;//175;//265;////135;//33;//464;          // 50uH
unsigned int PMSM_RS            =  150;//50;//155;//47;//25;//251;          // 11mohm
unsigned int PMS_L_R_UNIT       =  0;           //
#ifdef KE_WIDE_RANGE
unsigned int PMSM_KE            =  30;//24;//60;    //һ��С����
#else
unsigned int PMSM_KE            =  4;//6;           // ke = 4
#endif

///////////////////////////////////////////////////////////////////////////////////////
// �����л��ջ���������
///////////////////////////////////////////////////////////////////////////////////////
unsigned int FRQ_OPEN_TO_CLOSE      =  1500;    // Ҫ����һ�µ�λ������0.01HZ
unsigned int OPEN_LOOP_TOR_START    =  1000;
unsigned int FRQ_PWM_SHIFT_EN       =  10000;   // Ҫ����һ�µ�λ������0.01HZ

unsigned int LowLimit               =  450;     // ������������ ���Ʊ�ϵ��
unsigned int HighLimit              =  1000;    // ������������ ���Ʊ�ϵ��

#define SpinControlHZ                  5625              // ˳��������ֵ��, 0.01HZ
long SpinControlInternal   =  (long)SpinControlHZ << 4;  // ˳��������ֵ��, �ڲ���λ��OMG,must be long as pm_est_lpf_omg1 is long

///////////////////////////////////////////////////////////////////////////////////////
// Ƶ�ʺͼӼ��ٲ�������
///////////////////////////////////////////////////////////////////////////////////////
volatile int RefSet                 =  7000;   // 120.00HZ
unsigned int ACC1                   =  500;     // ���ٶμ���ʱ�� 5.0S
unsigned int ACC2                   =  200;     // ���ٶμ���ʱ�� 2.0S
unsigned int DCBrakeTime            =  20;      // ֱ���ƶ�ʱ��     1.0S

///////////////////////////////////////////////////////////////////////////////////////
// �ٶȻ���������
///////////////////////////////////////////////////////////////////////////////////////
unsigned int F_CHANGING_POINT_1_PI  =  200;
unsigned int F_CHANGING_POINT_2_PI  =  3000;
unsigned int LOW_SPEED_KI           =  40;//30;
unsigned int LOW_SPEED_KP           =  40;//30;
unsigned int HIGH_SPEED_KI_GAIN     =  10;//20;
unsigned int HIGH_SPEED_KP_GAIN     =  10;


///////////////////////////////////////////////////////////////////////////////////////
// ����������������
///////////////////////////////////////////////////////////////////////////////////////
volatile unsigned int D_CUR_KI               =  50;//60;
volatile unsigned int D_CUR_KP               =  50;//60;
volatile unsigned int Q_CUR_KI               =  10;//60;
volatile unsigned int Q_CUR_KP               =  20;//60;

///////////////////////////////////////////////////////////////////////////////////////
// ���Ʋ�������
///////////////////////////////////////////////////////////////////////////////////////
unsigned int PWM_FREQUENCY          =  180;//200;     // 100 * 0.1kHz �ز�Ƶ��
unsigned int AVR_MODE               =  1;       // AVR. 0,1: Enable, 2:Disabled

//--------------------- Ƶ�ʷ�Χ����----------------------/
unsigned int MAX_LIMIT_FREQ         =  40000;   // 300.00Hz
unsigned int MOTOR_RATED_FRE        =  5000;//40000;
unsigned int COAST_STOP_FRQ         =  500;     // 1.0HZ,����ͣ����ʼƵ��

//--------------------- ֱ���ƶ�����----------------------/
unsigned int DC_CONTROL_KP          = 15;//20;
unsigned int DC_CONTROL_KI          = 10;//20;
unsigned int DC_BRAKE_CUR           = 3000;//4100;

//--------------------- �������ưٷֱȲ���-------------/
unsigned int TORQUE_CUR_LIMIT       = 200;//100;

//--------------------- ���Ų���----------------------/
unsigned int FILED_WEEKING_MODE     = 2;       // FE-00, 0 ~ 2
unsigned int FILED_WEEKING_CUR_SCAL = 80;      // FE-01, 0 ~ 200
unsigned int FILED_WEEKING_SCAL     = 4;       // FE-02, 1 ~ 10
unsigned int FIELD_WEAK_REF         = 3950;    // FE-05, 0 ~ 4100
unsigned int IPD_PERIOD_SCALING     = 128;     // ���������������ر�С�������е����ܴ�

unsigned int SOFT_OC_POINT          = 15000;   // Current limit : 3A,150%
                                               // 9000 * 5 / 4096 = 11A
unsigned int STALL_PR_TIME          = 8;       // 8s, 8000ms

unsigned int SF_LOW_SPEED            = 160;
unsigned int MIN_CUR_LOW_SPEED       = 20;

unsigned int OVER_SPEED_SCALING      = 130;

//--------------------- FOC �������Ʋ���----------------------/
unsigned int SPEED_FEEDBACK_FILTER   = 56;
unsigned int FILED_WEEKING_OUTVOL_SC = 0;
unsigned int SPECIAL_FACTOR_1        = 0;
unsigned int SPEED_MEASURE_PAR_1     = 20;
unsigned int SPEED_MEASURE_PAR_2     = 20;
unsigned int START_PRESET_CUR        = 0;
unsigned int LOW_LIMIT_FREQUENCY     = 0;
unsigned int INIT_POS_DECTION_MODE   = 1;
unsigned int INIT_POS_DECTION_CUR    = 120;
unsigned int INIT_POS_DECTION_TIME   = 60;
unsigned int LOW_SPEED_FILTER        = 16;
unsigned int PMSM_RS_MIN             = 16;

//--------------------- ���������  ����----------------------/
unsigned int T_DELAY                = 150; // 1.5us
unsigned int T_SAMPLE               = 150; // 1.5us
//#define  CURR_SAMPLE_DELAY         (T_SAMPLE - T_DELAY)
//#define  MIN_SAMPLE_TIME           (T_SAMPLE + T_DELAY)
//#define  TWO_MIN_SAMPLE_TIME       (MIN_SAMPLE_TIME*2)

unsigned int FirstSamplePointShift  = 100; // 1.0us
unsigned int SecondSamplePointShift = 100; // 1.0us

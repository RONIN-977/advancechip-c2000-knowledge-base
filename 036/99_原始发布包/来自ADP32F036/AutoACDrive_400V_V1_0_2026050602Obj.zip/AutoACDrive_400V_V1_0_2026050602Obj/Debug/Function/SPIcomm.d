# FIXED

Function/SPIcomm.obj: ../Function/SPIcomm.c
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/SPIcomm.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Main.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/FuncCode.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Debug.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/FuncCode.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Interface.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Param_lr.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Define.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/MotorInclude.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/MainInclude.h
Function/SPIcomm.obj: E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/SubPrgInclude.h

../Function/SPIcomm.c:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/SPIcomm.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Main.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/FuncCode.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Debug.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/FuncCode.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Interface.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Param_lr.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/Define.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/MotorInclude.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/MainInclude.h:

E:/6.Adv_Code/ADP32F036/ADP036YsuojiDemo/AutoACDrive_400V_V1_0_2026050602Obj/HeardFiles/SourceHeader/SubPrgInclude.h:


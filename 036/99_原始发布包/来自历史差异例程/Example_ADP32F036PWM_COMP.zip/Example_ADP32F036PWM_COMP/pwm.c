#include "OnChip_Driver_Inc.h"
#include "BspInc.h"

pwm PWM5B={UP,0,200};

//pwm 10K Ƶ�ʣ��������PWMģʽ��������������ģʽ��
void InitEPwm5(void)
{
    volatile struct EPWM_REGS *PWMDef = &EPwm5Regs;
    //����GPIO40 Ϊ PWM7A��������;����GPIO41 Ϊ PWM5B��������
    EALLOW;
    GpioCtrlRegs.GPAPUD.bit.GPIO8 = 1;    // Disable pull-up on GPIO8 (EPWM5A)
    GpioCtrlRegs.GPAMUX1.bit.GPIO8 = 1;   // Configure GPIO8 as EPWM5A
    GpioCtrlRegs.GPAPUD.bit.GPIO9 = 1;    // Disable pull-up on GPIO9 (EPWM5B)
    GpioCtrlRegs.GPAMUX1.bit.GPIO9 = 1;   // Configure GPIO9 as EPWM5B
    EDIS;


    EALLOW;
    //T_PWM =2 x TBPRD x T_TBCLK
    PWMDef->TBPRD = frequency-1;     //Ƶ��
    //   Setup compare
    PWMDef->CMPA.half.CMPA = 0;  //PWMxAռ�ձ�
    PWMDef->CMPB = 0;  //PWMxBռ�ձ�

    PWMDef->TBPHS.half.TBPHS = 0x0000;            // Phase is 0
    PWMDef->TBCTR = 0x0000;                       // Clear counter

    // Setup TBCLK
    PWMDef->TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; // Count up down���м�������ģʽ
    PWMDef->TBCTL.bit.PHSEN = TB_DISABLE;        // Disable phase loading
    PWMDef->TBCTL.bit.SYNCOSEL = TB_SYNC_DISABLE;
    PWMDef->TBCTL.bit.HSPCLKDIV = TB_DIV1;       // Clock ratio to SYSCLKOUT;
    PWMDef->TBCTL.bit.CLKDIV =    TB_DIV1;

    //Configuration Options for the Dead-Band Submodule
    PWMDef->DBCTL.bit.OUT_MODE = DB_DISABLE;        //S1 = 0; S0 = 0 �ر���������

    // Set actions AQ�����������Ϊ��TBCTR����CxU/CxDʱ��AQ��PWMxA/PWMxB����ĸߵ�
    PWMDef->AQCTLA.bit.CAU = AQ_SET ;
    PWMDef->AQCTLA.bit.CAD = AQ_CLEAR;
    PWMDef->AQCTLB.bit.CBU = AQ_SET ;
    PWMDef->AQCTLB.bit.CBD = AQ_CLEAR;


//�����Ƚ����������

    PWMDef->TZCLR.all = 0x07;

    PWMDef->DCACTL.bit.EVT1SRCSEL = DC_EVT1;          // DCAEVT1 Source Is DCAEVT1 Signal
    PWMDef->DCACTL.bit.EVT1FRCSYNCSEL = DC_EVT_ASYNC; // DCAEVT1 Force Synchronization Signal Select: Asynchronous Signal

    PWMDef->TZDCSEL.bit.DCAEVT1 = TZ_DCAH_LOW;        // Digital Compare Output A Event 1 Selection:
                                                            // DCAH = low, DCAL = don't care
    PWMDef->DCTRIPSEL.bit.DCAHCOMPSEL = DC_COMP1OUT;  // Digital Compare A Low Input Select: COMP1OUT input
    PWMDef->DCTRIPSEL.bit.DCALCOMPSEL = DC_TZ2;       // Digital Compare B Low Input Select: TZ2
                                                            // TZ1,TZ3 ASLO OK as DCAL don't care

    PWMDef->TZSEL.bit.DCAEVT1 = 1;                    // Enable DCAEVT1 as one-shot-trip source for this ePWM module
    #ifndef CUT_DOWN_VER_HARDWARE
        PWMDef->TZCTL.all = 0x0005;
    #else
        PWMDef->TZCTL.all = 0x00A0;
    #endif

    // EPwm2Regs.TZEINT.bit.OST = TZ_ENABLE;        //���ù����ж�
    // Digital Comparator Output A Event 1 Interrupt Enable
    PWMDef->TZEINT.all = 0x0004;

    // EPwm2Regs.ETPS.all = 0x0101;
    PWMDef->ETPS.bit.INTPRD = 1;

    EDIS;
}

void InitEPwm1_AQ_DB(void)
{
    volatile struct EPWM_REGS *PWMDef = &EPwm1Regs;
    InitEPwm1Gpio();

    EALLOW;
    //T_PWM =2 x TBPRD x T_TBCLK
    PWMDef->TBPRD = frequency-1;            //Ƶ��
    //EPwm1Regs.TBCTL.bit.PRDLD = TB_SHADOW;
    PWMDef->CMPA.half.CMPA = 0;  //ռ�ձ�
    PWMDef->TBPHS.half.TBPHS = 0x0000;            // Phase is 0
    PWMDef->TBCTR = 0x0000;                       // Clear counter

    // Setup TBCLK
    PWMDef->TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; // Count up down
    PWMDef->TBCTL.bit.PHSEN = TB_DISABLE;        // Disable phase loading
    PWMDef->TBCTL.bit.SYNCOSEL = TB_SYNC_DISABLE;
    PWMDef->TBCTL.bit.HSPCLKDIV = TB_DIV1;       // Clock ratio to SYSCLKOUT;
    PWMDef->TBCTL.bit.CLKDIV =    TB_DIV1;
    PWMDef->CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    PWMDef->CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    PWMDef->CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;
    PWMDef->CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;

    // Set actions
    PWMDef->AQCTLA.bit.CAU = AQ_SET;
    PWMDef->AQCTLA.bit.CAD = AQ_CLEAR;

    //Configuration Options for the Dead-Band Submodule
    PWMDef->DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;        //S1 = 1; S0 = 1 ����������Ч
    //��������S0��S1ͬʱ�ر�ʱ������2�����ú���
    PWMDef->DBCTL.bit.OUT_MODE = DBA_ALL;           //S5 = 0; S4 = 0
    PWMDef->DBCTL.bit.POLSEL = DB_ACTV_HIC;         //S3 = 1; S2 = 0

    //����������������Ч����£��������ò���Ч��
    PWMDef->DBFED = 100; // FED = 100 TBCLKs, 1us
    PWMDef->DBRED = 100; // RED = 100 TBCLKs  1us
    EDIS;
}

//�ı�ռ�ձ�
void ChangePWMDutyCycle()
{
    switch(PWM5B.dutyDir)
    {
        case UP:
               if(PWM5B.dutyCycle >= frequency)
               {
                   PWM5B.dutyCycle = frequency-PWM5B.PWMstep;
                   PWM5B.dutyDir = DOWM;          //PWM�����Ƽ�����������
                   LED1_TOGGLE();

               }
               else
                   PWM5B.dutyCycle += PWM5B.PWMstep ;
        break;

        case DOWM:
               if(PWM5B.dutyCycle <= PWM5B.PWMstep )
               {
                   PWM5B.dutyCycle = PWM5B.PWMstep;
                   PWM5B.dutyDir = UP;            //PWM������������������
                   LED1_TOGGLE();

               }
               else
                   PWM5B.dutyCycle -= PWM5B.PWMstep ;
        break;

        case STOP:
            PWM5B.dutyCycle = PWM5B.dutyCycle ;
        break;
    }
    EPwm5Regs.CMPB= PWM5B.dutyCycle;            //�ı�PWM5Bռ�ձ�
    EPwm5Regs.CMPA.half.CMPA = PWM5B.dutyCycle; //�ı�PWM7Aռ�ձ�
}



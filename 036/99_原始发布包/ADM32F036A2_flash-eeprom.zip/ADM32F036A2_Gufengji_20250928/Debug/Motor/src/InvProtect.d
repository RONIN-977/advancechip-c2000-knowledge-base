# FIXED

Motor/src/InvProtect.obj: ../Motor/src/InvProtect.c
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/SourceHeader/MotorInclude.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/SourceHeader/MainInclude.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/SourceHeader/Define.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_Device.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_Adc.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_BootVars.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_DevEmu.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_Cla.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_Comp.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_CpuTimers.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_ECan.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_ECap.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_EPwm.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_EQep.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_Gpio.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_I2c.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_Lin.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_NmiIntrupt.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_PieCtrl.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_PieVect.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_Spi.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_Sci.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_SysCtrl.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_XIntrupt.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_PgaOpa.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/SourceHeader/SubPrgInclude.h
Motor/src/InvProtect.obj: E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/SourceHeader/Record.h

../Motor/src/InvProtect.c:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/SourceHeader/MotorInclude.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/SourceHeader/MainInclude.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/SourceHeader/Define.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_Device.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_Adc.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_BootVars.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_DevEmu.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_Cla.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_Comp.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_CpuTimers.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_ECan.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_ECap.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_EPwm.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_EQep.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_Gpio.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_I2c.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_Lin.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_NmiIntrupt.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_PieCtrl.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_PieVect.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_Spi.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_Sci.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_SysCtrl.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_XIntrupt.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/280xHeader/DSP2803x_PgaOpa.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/SourceHeader/SubPrgInclude.h:

E:/6.Adv_Code/ADP16F036/chaoli12Vdianchibaogufengji/Release/Chaoli100WGufengjiRelease20250928/ADM32F036A2_Gufengji_20250928/HeardFiles/SourceHeader/Record.h:


# FIXED

Motor/src/HALL/AngleMeasHall.obj: ../Motor/src/HALL/AngleMeasHall.c
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/AngleMeasHall.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Device.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Adc.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_BootVars.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_DevEmu.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Cla.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Comp.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_CpuTimers.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_ECan.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_ECap.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_EPwm.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_EQep.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Gpio.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_I2c.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Lin.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_NmiIntrupt.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PieCtrl.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PieVect.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Spi.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Sci.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_SysCtrl.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_XIntrupt.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PgaOpa.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/HallHandle.h
Motor/src/HALL/AngleMeasHall.obj: C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Record.h

../Motor/src/HALL/AngleMeasHall.c: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/AngleMeasHall.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Device.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Adc.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_BootVars.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_DevEmu.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Cla.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Comp.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_CpuTimers.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_ECan.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_ECap.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_EPwm.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_EQep.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Gpio.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_I2c.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Lin.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_NmiIntrupt.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PieCtrl.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PieVect.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Spi.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_Sci.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_SysCtrl.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_XIntrupt.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/280xHeader/DSP2803x_PgaOpa.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/HallHandle.h: 
C:/Users/50730/git/FOC_Sensor/Hall_Encorder/ADM32F036A3HallFOC/HeardFiles/SourceHeader/Record.h: 

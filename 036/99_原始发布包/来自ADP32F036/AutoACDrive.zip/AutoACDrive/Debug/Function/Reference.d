# FIXED

Function/Reference.obj: ../Function/Reference.c
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Define.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/FrqSrc.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/FuncCode.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Debug.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/FuncCode.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Main.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Interface.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/RunSrc.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/IO.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Parameter.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/SubPrgInclude.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/MotorInclude.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/MainInclude.h
Function/Reference.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/param_lr.h

../Function/Reference.c:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Define.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/FrqSrc.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/FuncCode.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Debug.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/FuncCode.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Main.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Interface.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/RunSrc.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/IO.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Parameter.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/SubPrgInclude.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/MotorInclude.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/MainInclude.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/param_lr.h:


# FIXED

Main/MainSystem.obj: ../Main/MainSystem.c
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/CANcomm.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/MainInclude.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Define.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/SubPrgInclude.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/MotorInclude.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/param_lr.h
Main/MainSystem.obj: E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/SPIcomm.h

../Main/MainSystem.c:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/CANcomm.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Device.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Adc.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_BootVars.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_DevEmu.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Cla.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Comp.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_CpuTimers.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_ECan.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_ECap.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_EPwm.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_EQep.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Gpio.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_I2c.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Lin.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_NmiIntrupt.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PieCtrl.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PieVect.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Spi.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_Sci.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_SysCtrl.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_XIntrupt.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/ADP32F03xHeader/ADP32F03x_PgaOpa.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/MainInclude.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/Define.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/SubPrgInclude.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/MotorInclude.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/param_lr.h:

E:/6.Adv_Code/ADP32F036/LinDong/600V_YaSuoJi_3427/Release/LingDong_V3427_600V_20260513Release/HeardFiles/SourceHeader/SPIcomm.h:


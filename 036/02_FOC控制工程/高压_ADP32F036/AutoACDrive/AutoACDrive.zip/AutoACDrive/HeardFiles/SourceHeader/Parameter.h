
#ifndef __F_PARAMETER_H__
#define __F_PARAMETER_H__

#define YellowLED_ON                GpioDataRegs.GPASET.bit.GPIO18      = 1
#define YellowLED_OFF               GpioDataRegs.GPACLEAR.bit.GPIO18    = 1

//--------------------- SVPWM��ص���  ����----------------------/
extern unsigned int FIVEPWM_FRQ_SET;       // 100.00Hz
extern unsigned int DPWM_FRQ_LEVEL;        // 5.00Hz
extern unsigned int Zero_Length_Min;
extern unsigned int Zero_Length_Min2;
extern unsigned int RandomSezeorVectorModeEn;
extern unsigned int RandomZero_FRQ_SET;

#define TRIP_FLASHING_TIME          250
#define TRIP_FLASHING_TIMEX2        250*2
#define TRIP_FLASHING_TIMEX4        250*6

#define WAIT_POWER_ON_TIME          10000       // ����������֮�󣬵ȴ�_*0.5ms��ʼ��ӦǷѹ��������������

#define SWITCH_FREQUENCY_EMC_TYPE       FIXED_SWICTH_FREQUENCY  // �̶�����Ƶ�ʻ������
#define SWITCH_FREQUENCY_AMP            20                      // ������Ƶֵ

#define SF_INDEPAND_OF_FREQUENCY        SW_RANDOM_DISABLE

///////////////////////////////////////////////////////////////////////////////////////
// ���ư��������
///////////////////////////////////////////////////////////////////////////////////////
extern unsigned long MAX_PEAK_CUR_3_3V_410;
extern unsigned int MAX_DC_VOL_3_3V;

extern unsigned int OVER_DC_VOL_POINT;
extern unsigned int OVER_DC_VOL_LIMIT;
extern unsigned int UNDER_DC_VOL_POINT;

extern unsigned int OverCurPointInternal;
extern unsigned int CBCCurPointInternal;

extern unsigned int DeadTimeInternal;
extern unsigned int DeadTimeCompInternal;

///////////////////////////////////////////////////////////////////////////////////////
// �����������
///////////////////////////////////////////////////////////////////////////////////////
extern unsigned int MOTOR_RATED_POWER;    //0.1WΪ��λ
extern unsigned int MOTOR_RATED_VOL;
extern unsigned int MOTOR_RATED_CUR;
extern unsigned int LOWER_LIMIT_FREQ;

extern unsigned int PMSM_PN;
extern unsigned int PMSM_LD;          // 37uH
extern unsigned int PMSM_LQ;          // 50uH
extern unsigned int PMSM_RS;          // 11mohm
extern unsigned int PMS_L_R_UNIT;           //
#ifdef KE_WIDE_RANGE
extern unsigned int PMSM_KE;          // Ke = 43
#else
extern unsigned int PMSM_KE;           // ke = 4
#endif

///////////////////////////////////////////////////////////////////////////////////////
// �����л��ջ���������
///////////////////////////////////////////////////////////////////////////////////////
extern unsigned int FRQ_OPEN_TO_CLOSE;    // Ҫ����һ�µ�λ������0.01HZ
//extern unsigned int FULL_OPEN_LOOP_MODE;       // ����ģʽ����ֹ���θ���
extern unsigned int OPEN_LOOP_TOR_START;
extern unsigned int FRQ_PWM_SHIFT_EN;   // Ҫ����һ�µ�λ������0.01HZ

///////////////////////////////////////////////////////////////////////////////////////
// �ٶȻ���������
///////////////////////////////////////////////////////////////////////////////////////
extern unsigned int F_CHANGING_POINT_1_PI;
extern unsigned int F_CHANGING_POINT_2_PI;
extern unsigned int LOW_SPEED_KI;
extern unsigned int LOW_SPEED_KP;
extern unsigned int HIGH_SPEED_KI_GAIN;
extern unsigned int HIGH_SPEED_KP_GAIN;

///////////////////////////////////////////////////////////////////////////////////////
// ���Ʋ�������
///////////////////////////////////////////////////////////////////////////////////////
extern unsigned int PWM_FREQUENCY;     // 100 * 0.1kHz �ز�Ƶ��
extern unsigned int AVR_MODE;

///////////////////////////////////////////////////////////////////////////////////////
// ����������������
///////////////////////////////////////////////////////////////////////////////////////
extern unsigned int D_CUR_KI;
extern unsigned int D_CUR_KP;
extern unsigned int Q_CUR_KI;
extern unsigned int Q_CUR_KP;


//--------------------- Ƶ�ʷ�Χ����----------------------/
extern unsigned int MAX_LIMIT_FREQ;   // 300.00Hz
extern unsigned int MOTOR_RATED_FRE;
extern unsigned int COAST_STOP_FRQ;    // 1.0HZ,����ͣ����ʼƵ��

//--------------------- ֱ���ƶ�����----------------------/
extern unsigned int DC_CONTROL_KP;
extern unsigned int DC_CONTROL_KI;
extern unsigned int DC_BRAKE_CUR;

extern unsigned int TORQUE_CUR_LIMIT;

extern long SpinControlInternal;

extern unsigned int FILED_WEEKING_MODE;         // FE-00, 0 ~ 2
extern unsigned int FILED_WEEKING_CUR_SCAL;     // FE-01, 0 ~ 200
extern unsigned int FILED_WEEKING_SCAL;         // FE-02, 1 ~ 10
extern unsigned int FIELD_WEAK_REF;             // FE-05, 0 ~ 4100
extern unsigned int IPD_PERIOD_SCALING;         // ���������������ر�С�������е����ܴ�
extern unsigned int SOFT_OC_POINT;              // Current limit : 3A,150%
extern unsigned int IdMaxScaling;
extern unsigned int STALL_PR_TIME;              // 8s, 8000ms

extern unsigned int OVER_SPEED_SCALING;
extern unsigned int SPEED_FEEDBACK_FILTER;
extern unsigned int SF_LOW_SPEED;
extern unsigned int MIN_CUR_LOW_SPEED;
extern unsigned int FILED_WEEKING_OUTVOL_SC;
extern unsigned int SPECIAL_FACTOR_1;
extern unsigned int SPEED_MEASURE_PAR_1;
extern unsigned int SPEED_MEASURE_PAR_2;
extern unsigned int START_PRESET_CUR;
extern unsigned int LOW_LIMIT_FREQUENCY;
extern unsigned int INIT_POS_DECTION_MODE;
extern unsigned int INIT_POS_DECTION_CUR;
extern unsigned int INIT_POS_DECTION_TIME;
extern unsigned int LOW_SPEED_FILTER;
extern unsigned int PMSM_RS_MIN;

extern unsigned int T_DELAY;
extern unsigned int T_SAMPLE;
extern unsigned int FirstSamplePointShift;
extern unsigned int SecondSamplePointShift;

extern unsigned int LowLimit;
extern unsigned int HighLimit;

extern int RefSet;
extern unsigned int ACC1;
extern unsigned int ACC2;
extern unsigned int DEC;
extern unsigned int DCBrakeTime;

extern unsigned int ThetaCoff;
extern unsigned int AUTO_RESET_CNT;
extern unsigned int AVR_Mode;
extern unsigned int TS_L_VDC_SCALING;

extern unsigned int AlfaValueForOBS;                        // Alfa: 1000 ~ 3000
extern unsigned int LamdaValueForOBS;                       // Lamda:2 ~ 16
extern unsigned int FilterCntLowForOBS;                     // High: 5
extern unsigned int FilterCntHighForOBS;                    // LOW:  8

extern unsigned long IdMinInternal;                        // 5 * 1602
extern unsigned long IdMaxInternal;                        // 50 * 1602

#endif // __F_PARAMETER_H__


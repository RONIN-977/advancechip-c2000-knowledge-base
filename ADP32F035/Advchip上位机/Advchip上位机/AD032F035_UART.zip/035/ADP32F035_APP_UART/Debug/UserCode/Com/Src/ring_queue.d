# FIXED

UserCode/Com/Src/ring_queue.obj: ../UserCode/Com/Src/ring_queue.c
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/UserCode/Com/Inc/ring_queue.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Project.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Cla_typedefs.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Device.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Adc.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_BootVars.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_DevEmu.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Cla.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Comp.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_CpuTimers.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_ECan.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_ECap.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_EPwm.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_EQep.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Gpio.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_HRCap.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_I2c.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Lin.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_NmiIntrupt.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_PieCtrl.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_PieVect.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Spi.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Sci.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_SysCtrl.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_XIntrupt.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Examples.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_GlobalPrototypes.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_EPwm_defines.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_I2c_defines.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Cla_defines.h
UserCode/Com/Src/ring_queue.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_DefaultISR.h

../UserCode/Com/Src/ring_queue.c: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/UserCode/Com/Inc/ring_queue.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Project.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Cla_typedefs.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Device.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Adc.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_BootVars.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_DevEmu.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Cla.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Comp.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_CpuTimers.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_ECan.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_ECap.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_EPwm.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_EQep.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Gpio.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_HRCap.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_I2c.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Lin.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_NmiIntrupt.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_PieCtrl.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_PieVect.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Spi.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Sci.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_SysCtrl.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_XIntrupt.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Examples.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_GlobalPrototypes.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_EPwm_defines.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_I2c_defines.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_Cla_defines.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/ADP32F035_Routine/ADP32F035_APP_UART/Library/Per_Inc/ADP32F03x_DefaultISR.h: 

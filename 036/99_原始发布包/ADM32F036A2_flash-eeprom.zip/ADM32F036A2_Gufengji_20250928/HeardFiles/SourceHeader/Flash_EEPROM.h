/*
 * Flash_EEPROM.h
 *
 *  Created on: 2025��8��14��
 *      Author: Advancechip
 */

#ifndef HEARDFILES_SOURCEHEADER_FLASH_EEPROM_H_
#define HEARDFILES_SOURCEHEADER_FLASH_EEPROM_H_
#include "Flash_ADP32F03x_API_Library.h"
#include "Flash_ADP32F03x_API_Config.h"

#define EEPROM_SIZE  (Uint16)0x0080        // EEPROM��С(128 words)

#define EEPROM_START ((Uint16 *)0x3F5C00)  // EEPROM(FLASHB)��ʼ��ַ
#define EEPROM_ALL   (Uint16)0x0002

// ״̬����
#define STATUS_SUCCESS 0
#define STATUS_FAIL    1

// ȫ�ֱ�������״̬
extern FLASH_ST FlashStatus;

Uint16 Flash_EEPROM_WriteWord(Uint16 *FlashAddr, Uint16 *DataBuf, Uint32 Length);
Uint16 Flash_EEPROM_EraseAll(Uint16 SectorMask);
Uint16 Flash_EEPROM_Erase_OneWord(Uint16 *Addr);
Uint16 Flash_EEPROM_ReadWord(Uint16 *FlashAddr);
#endif /* HEARDFILES_SOURCEHEADER_FLASH_EEPROM_H_ */

#ifndef BOARD_CONFIG_H
#define BOARD_CONFIG_H
#include "driverlib.h"
/* [移植必需 客户适配] 本文件随升级模块复制。
 * 改 CAN 控制器、引脚、速率或节点时，配套 BOOT 必须同步；
 * 客户已有业务 ID 时，确认 0x600+节点/0x580+节点没有冲突。
 * GPIO17 LED 宏仅用于示例 main，客户不需要照搬。
 */
/* Project pin selection; TI mux constants are in vendor/device/driverlib/pin_map.h.
 * CCS ProjectSpec copies this file to include/board_config.h in BOTH projects.
 * boot_ports_init() uses BOOT_* macros, not vendor/device/device.h board defaults.
 */
#define BOOT_CAN_BASE CANA_BASE
#define BOOT_CAN_RX_GPIO 30U
#define BOOT_CAN_TX_GPIO 31U
#define BOOT_CAN_RX_CONFIG GPIO_30_CANA_RX
#define BOOT_CAN_TX_CONFIG GPIO_31_CANA_TX
/* Application LED: one transition every 500 ms; one full cycle per second.
 * Initialized only by the application, not by the bootloader.
 */
#define APP_LED_GPIO 17U
#define APP_LED_CONFIG GPIO_17_GPIO17
#define APP_LED_TOGGLE_MS 500UL
#ifndef BOOT_CAN_BAUD
#define BOOT_CAN_BAUD 500000UL
#endif
#define BOOT_NODE_ID 1U
#define BOOT_CAN_RX_ID (0x600U + BOOT_NODE_ID)
#define BOOT_CAN_TX_ID (0x580U + BOOT_NODE_ID)
#define BOOT_LISTEN_MS 5000UL
#define BOOT_SESSION_MS 30000UL
#define BOOT_PARTIAL_MS 200UL
#define BOOT_METADATA 0x08F000UL
/* Optional board-level force-boot input disabled until a pin is allocated. */
#define BOOT_FORCE_GPIO 0xFFFFU
/* Clock source is configured in vendor/device/device.h: 20 MHz XTAL, 120 MHz SYSCLK. */
#endif

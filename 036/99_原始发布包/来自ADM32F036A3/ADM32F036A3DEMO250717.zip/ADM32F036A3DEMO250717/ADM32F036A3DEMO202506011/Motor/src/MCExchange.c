
#include "MotorInclude.h"
#include "Main.h"
#include "Parameter.h"

/*************************************************************
**************************************************************
	�ӹ���ģ���ȡ��Ҫ�����в���
*************************************************************/
#ifdef SWITCH_FRE_EMC
unsigned int PWMFreSetFlag = 0;
unsigned int RandomNum = 10000;
unsigned int RandomNum1 = 0;
unsigned int RandomNum2 = 10000;
unsigned int PWMFreSet = 160;
#endif
//int EnableRecord2[5];
void ParGetFromFunction(void)
{
	int m_Index;
	int data;
	long freqs,data1,data2,ki,kp;

	pm_control_mode = PMSM_CONTROL_MODE_FOC;

#if SWITCH_FRE_EMC
    RandomNum = PWMFreSet * 229;

    if(RandomNum1 <= RandomNum)
        RandomNum1++;
    else
        RandomNum1 = 0;

    if(RandomNum2 >= 10)
        RandomNum2--;
    else
        RandomNum2 = RandomNum;

    PWMFreSet = (RandomNum1*RandomNum2)%190;
    EnableRecord2[1] = PWMFreSet;
    if(PWMFreSet <= 165)
    {
        if(PWMFreSet >=80)
            PWMFreSet = 165 + (PWMFreSet >>3);
        else
            PWMFreSet = 165 + (PWMFreSet >>3);
    }
    else if(PWMFreSet >= 185)
    {
        PWMFreSet = 185;
    }

    gBasePar.FcSetApply = PWMFreSet;
    gFcCal.FcBak  = PWMFreSet;
#endif

#if 0
//if (gMainStatus.RunStep == OPEN_ACC && gMainCmd.Command.bit.StartDC == 0) {
if (EnableRecord2[0] == 1) {
ControlAllowRecord(1,2);
IsRecordThisSample(
        RandomNum1,
        RandomNum2,
        RandomNum,
        EnableRecord2[1],
        PWMFreSet,
        gBasePar.FcSetApply,
        pm_est_omg >> 4
        );
}
#endif

    // ����ע�⣬��Щ��������Щ�Ǹ��洢�йص�...
	for(m_Index = 0;m_Index < FUNCTION_TO_MOTOR_DATA_NUM;m_Index++)
	{
		*gSendToMotorTable[m_Index] = gSendToMotorDataBuff[m_Index];
	}

	if(gMainCmd.Command.bit.TunePart != 0)
	{
		return;
	}

	// �ٶȻ�PI ����....
	// �Ƶ�ʣ�50Hz,>>6 = 0.78Hz...,Freqs with 0.01Hz units...
	// Ŀǰ����/����ƫ������Ϊ 1Hz 2Hz �ǲ����е�ƫС............
	data1 = pm_ref_speed;
	freqs = labs(data1)>>4;
	ki = LOW_SPEED_KI * 3;

	if (freqs <= 100) {
		// 200Hz, then 3.12Hz below������KI ��ǿ��KP���䡣
		pm_ki_speed = LOW_SPEED_KI * 6;
		pm_kp_speed = LOW_SPEED_KP;

		pm_speed_lpf_k = LOW_SPEED_FILTER;
		pm_speed_lpf_k = __IQsat(pm_speed_lpf_k,1024,4);
	} else if(freqs < F_CHANGING_POINT_1_PI) {
		// С�ڵ�һ���л��㣬KI ����3����KP���䡣
		//////////////////////////////////////
		pm_ki_speed = ki;
		pm_kp_speed = LOW_SPEED_KP;

		pm_speed_lpf_k = LOW_SPEED_FILTER;
		pm_speed_lpf_k = __IQsat(pm_speed_lpf_k,1024,4);
	} else if(freqs >= F_CHANGING_POINT_2_PI) {

		// ���ڵڶ����л��㣬ֱ���ø���PI����
		pm_ki_speed = HIGH_SPEED_KI_GAIN;
		pm_kp_speed = HIGH_SPEED_KP_GAIN;
		pm_speed_lpf_k = SPEED_FEEDBACK_FILTER;
		pm_speed_lpf_k = __IQsat(pm_speed_lpf_k,1024,4);
	} else {

		// һ��Ƶ���л���֮�䣬��ֵ����....
		// ������
		// ֮ǰ�� 0 ~ 4Hz: P = 20, I = 300
		// 4 ~ 10Hz:      P = 15, I = 150
		// > 10Hz:        P = 10, I = 100
		// ���ڿ��ǡ�
		// FE.30 = 4HZ. FE.33 = 40HZ
		// FE.04 = 10
		// FE.05 = 100
		// FE.31 = 30
		// FE.32 = 100
		/////////////////////////////////
		pm_speed_lpf_k = LOW_SPEED_FILTER;
		pm_speed_lpf_k = __IQsat(pm_speed_lpf_k,1024,4);
		data1 = (long)HIGH_SPEED_KI_GAIN - (long)ki;
		data1 = data1 * (freqs - (long)F_CHANGING_POINT_1_PI);
		data2 = (long)F_CHANGING_POINT_2_PI - (long)F_CHANGING_POINT_1_PI;
		data1 = data1 / data2;
		pm_ki_speed = (long)ki + data1;
		if(pm_ki_speed < 0)
		{
			pm_ki_speed = 0;
		}

		data1 = (long)HIGH_SPEED_KP_GAIN - (long)LOW_SPEED_KP;
		data1 = data1 * (freqs - (long)F_CHANGING_POINT_1_PI);
		data2 = (long)F_CHANGING_POINT_2_PI - (long)F_CHANGING_POINT_1_PI;
		data1 = data1 / data2;
		pm_kp_speed = (long)LOW_SPEED_KP + data1;
		if(pm_kp_speed < 0)
		{
			pm_kp_speed = 0;
		}
	}

	// ת�����Ʒ���
	if (pm_forbid_revtorq == 0)
	{  
		data = abs(gMainCmd.VCTorqueLim);
		pm_curr_limitH = (long)data * 4096/1000;
		pm_curr_limitL = -pm_curr_limitH;	
	}
	else
	{
		data = abs(gMainCmd.VCTorqueLim);
		if(gMainCmd.FreqSetApply >= 0)
		{
			pm_curr_limitH = (long)data * 4096/1000;
			pm_curr_limitL = 0;
		}
		else
		{
			pm_curr_limitH = 0;
			pm_curr_limitL = -(long)data * 4096/1000;
		}
	}

	// LD,LQ,RS ��λ����...
	data = PMS_L_R_UNIT%10;
	if(data == 0)
	{
		l_ld = (unsigned long)PMSM_LD;
		data1 = (unsigned long)PMSM_LQ;
	}
	if(data == 1)
	{
		l_ld = (unsigned long)PMSM_LD * 10;
		data1 = (unsigned long)PMSM_LQ * 10;
	}
	if( data == 2)
	{
		l_ld = (unsigned long)PMSM_LD * 100;
		data1 = (unsigned long)PMSM_LQ * 100;
	}
	l_lq =  (long)l_ld + (data1 - (long)l_ld)/3;

    data = PMS_L_R_UNIT/10;
    if(data == 0)
    {
        pm_r = (unsigned long)PMSM_RS;
    }
    else
    {
        pm_r = (unsigned long)PMSM_RS * 10;
    }

#if 1
	if(PMSM_KE != 500)
	{
		pm_bem_kf = PMSM_KE;
	}
	else
	{
#ifndef FREQUENCY_CONTROL_01HZ
        data = 10000L * (unsigned long)gMotorInfo.Votage/(unsigned long)gMotorInfo.Frequency;
#else
        data = 1000L * (unsigned long)gMotorInfo.Votage/(unsigned long)gMotorInfo.Frequency;
#endif
		pm_bem_kf = data;
	}
#else
    int PMBemfKeUsed;
    if (gMainCmd.FreqReal < 3000) {
        PMBemfKeUsed = PMSM_KE << 1;
    } else if (gMainCmd.FreqReal > 6000) {
        PMBemfKeUsed = PMSM_KE;
    } else {
        PMBemfKeUsed = ((long)(6000 - gMainCmd.FreqReal) * PMSM_KE) / (6000 - 3000);
        PMBemfKeUsed += PMSM_KE;
        if (PMBemfKeUsed > (PMSM_KE << 1)) PMBemfKeUsed = (PMSM_KE << 1);
        if (PMBemfKeUsed < (PMSM_KE << 0)) PMBemfKeUsed = (PMSM_KE << 0);
    }
    pm_bem_kf = PMBemfKeUsed;
#endif

	// DQ �������PI ϵ��,pm_especial_pi ����С��е�����Ŵ����������
	// �˴����漰....
	///////////////////////////////////////////////////////////////////
	pm_ki_d = (unsigned long)D_CUR_KI * 10;
    pm_ki_q = (unsigned long)Q_CUR_KI * 10;
    if(gBasePar.FcSetApply <= 40)
    {
        kp = (long)D_CUR_KP * gBasePar.FcSetApply>>2;
        kp = (long)Q_CUR_KP * gBasePar.FcSetApply>>2;
    } else {
        kp = (long)D_CUR_KP * 10;
        pm_kp_d = kp;
        kp = (long)Q_CUR_KP * 10;
        pm_kp_q = kp;
    }

    if ((gMainCmd.Command.bit.StartDC   == 1                 ) ||
        (gMainStatus.RunStep            == OPEN_ACC          ) ||
        (gMainStatus.RunStep            == HALF_OPEN_ACC     ))
    {
        pm_kp_d = pm_kp_d >> 2;
        pm_kp_q = pm_kp_q >> 2;
        pm_ki_d = pm_ki_d >> 1;
        pm_ki_q = pm_ki_q >> 1;
    } else if (gMainStatus.RunStep      == STATUS_SPEED_CHECK) {
        pm_kp_d = pm_kp_d << 3;
        pm_kp_q = pm_kp_q << 3;
        pm_ki_d = pm_ki_d << 3;
        pm_ki_q = pm_ki_q << 3;
    }
}
	
void CalParToFunction(void)
{

}

/*************************************************************
	�ѵ�����е�ʵʱ�������͸�����ģ��
*************************************************************/
void ParSendToFunction(void)		
{
	Uint m_Index;

	for (m_Index = 0;m_Index < MOTOR_TO_FUNCTION_DATA_NUM;m_Index++)
	{
		gSendToFunctionDataBuff[m_Index] = *gSendToFuncTable[m_Index];
	}
}

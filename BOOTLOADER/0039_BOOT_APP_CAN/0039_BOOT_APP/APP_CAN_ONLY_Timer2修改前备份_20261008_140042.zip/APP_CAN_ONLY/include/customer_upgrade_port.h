#ifndef CUSTOMER_UPGRADE_PORT_H
#define CUSTOMER_UPGRADE_PORT_H
#include <stdint.h>
/* [K04 客户实现] 完整系统初始化：时钟、GPIO、CAN、定时器、中断。
 * 可在客户自己的 main 中沿用原初始化，不必实现这个模板包装接口。
 */
void Customer_SystemInit(void);
/* [K04 客户实现] 原有后台任务；不能长期阻塞升级收帧。 */
void Customer_BackgroundTask(void);
/* [K05 客户实现] 单调 uint32_t 毫秒计数，允许自然回绕。
 * CAN 等待发送期间仍要更新，禁止仅依赖主循环自增。
 * 若由 ISR 写入，应按客户实现保证读取一致性。
 */
uint32_t Customer_GetMillis(void);
/* [K06 客户实现] 仅在有效 ENTER_BOOT 后调用。
 * 返回 1：控制输出已进入安全状态，且锁住业务重新启动。
 * 返回 0：本次不发成功应答、不写 RAM 标记、不复位；主机需重发请求。
 * 不要直接返回 1 占位，不在此无限等待；由客户停机状态机完成判定。
 */
uint16_t Customer_PrepareForUpgrade(void);
#endif

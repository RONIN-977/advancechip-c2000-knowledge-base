#ifndef UPGRADE_ENTRY_H
#define UPGRADE_ENTRY_H
/* Call init once after Device_init. Call poll frequently (<1 ms preferred).
 * In an existing application, adapt this to that application's own CAN
 * receive dispatcher instead of configuring the peripheral a second time.
 * Quiesce PWM/relays/control outputs BEFORE accepting an upgrade request. */
/* [移植必需] 在客户设备初始化后调用一次；已有 CAN/时基时裁掉重复初始化。 */
void upgrade_entry_init(void);
/* [移植必需] 后台主循环频繁调用，优选间隔 <1 ms；不在控制 ISR 中调用。 */
void upgrade_entry_poll(void);
#endif

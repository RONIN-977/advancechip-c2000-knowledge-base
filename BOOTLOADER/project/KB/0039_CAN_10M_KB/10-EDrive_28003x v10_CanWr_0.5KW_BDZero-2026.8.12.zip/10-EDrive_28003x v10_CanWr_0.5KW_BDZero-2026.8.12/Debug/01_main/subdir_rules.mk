################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
01_main/%.obj: ../01_main/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"D:/ti/ccs1110/ccs/tools/compiler/ti-cgt-c2000_21.6.0.LTS/bin/cl2000" -v28 -ml -mt --float_support=fpu32 --idiv_support=idiv0 --tmu_support=tmu0 -O3 --fp_mode=relaxed --include_path="E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x v10_CanWr_0.5KW_BDZero-2026.8.12/00_sys280025/common/include" --include_path="E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x v10_CanWr_0.5KW_BDZero-2026.8.12/FlashApi" --include_path="E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x v10_CanWr_0.5KW_BDZero-2026.8.12/FlashApi/include" --include_path="E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x v10_CanWr_0.5KW_BDZero-2026.8.12/FlashApi/include/FlashAPI" --include_path="E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x v10_CanWr_0.5KW_BDZero-2026.8.12/FlashApi/include/FlashAPI/Constants" --include_path="E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x v10_CanWr_0.5KW_BDZero-2026.8.12/01_main/02_can" --include_path="E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x v10_CanWr_0.5KW_BDZero-2026.8.12/00_sys280025/math_Lib" --include_path="E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x v10_CanWr_0.5KW_BDZero-2026.8.12/01_main" --include_path="E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x v10_CanWr_0.5KW_BDZero-2026.8.12/01_main/01_sysInit" --include_path="E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x v10_CanWr_0.5KW_BDZero-2026.8.12/00_sys280025/headers/include" --include_path="E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x v10_CanWr_0.5KW_BDZero-2026.8.12/00_sys280025/driverlib" --include_path="E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x v10_CanWr_0.5KW_BDZero-2026.8.12/00_sys280025/driverlib/inc" --include_path="E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x v10_CanWr_0.5KW_BDZero-2026.8.12/00_sys280025/user_define" --include_path="E:/Work/Software/Ti/TI280033/96-DongQing/10-EDrive_28003x v10_CanWr_0.5KW_BDZero-2026.8.12" --include_path="D:/ti/ccs1110/ccs/tools/compiler/ti-cgt-c2000_21.6.0.LTS/include" --advice:performance=all --define=DEBUG --define=_FLASH --diag_suppress=10063 --diag_warning=225 --diag_wrap=off --display_error_number --gen_func_subsections=on --abi=eabi --preproc_with_compile --preproc_dependency="01_main/$(basename $(<F)).d_raw" --obj_directory="01_main" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '



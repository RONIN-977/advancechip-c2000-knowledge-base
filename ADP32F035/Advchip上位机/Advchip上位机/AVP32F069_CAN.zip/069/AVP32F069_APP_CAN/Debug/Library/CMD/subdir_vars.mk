################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../Library/CMD/AVP32F069_FLASH.cmd \
../Library/CMD/AVP32F069_Headers_nonBIOS.cmd 



# FIXED

Library/Per_Src/AVP32F069_OscComp.obj: ../Library/Per_Src/AVP32F069_OscComp.c
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Device.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Adc.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_BootVars.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Cla.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Comp.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_CpuTimers.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_DevEmu.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Dma.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_ECan.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_ECap.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_EPwm.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_EQep.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Gpio.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_HRCap.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_I2c.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Mcbsp.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_NmiIntrupt.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_PieCtrl.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_PieVect.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Spi.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Sci.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_SysCtrl.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Usb.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_XIntrupt.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Examples.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_GlobalPrototypes.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_EPwm_defines.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_I2c_defines.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Dma_defines.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Cla_defines.h
Library/Per_Src/AVP32F069_OscComp.obj: D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_DefaultISR.h

../Library/Per_Src/AVP32F069_OscComp.c: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Device.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Adc.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_BootVars.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Cla.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Comp.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_CpuTimers.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_DevEmu.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Dma.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_ECan.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_ECap.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_EPwm.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_EQep.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Gpio.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_HRCap.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_I2c.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Mcbsp.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_NmiIntrupt.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_PieCtrl.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_PieVect.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Spi.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Sci.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_SysCtrl.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Usb.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_XIntrupt.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Examples.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_GlobalPrototypes.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_EPwm_defines.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_I2c_defines.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Dma_defines.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_Cla_defines.h: 
D:/Mr_Wei/AdvanceChip/02_SoftWare/AVP32F069_Routine/AVP32F069_APP_CAN/Library/Per_Inc/AVP32F069_DefaultISR.h: 

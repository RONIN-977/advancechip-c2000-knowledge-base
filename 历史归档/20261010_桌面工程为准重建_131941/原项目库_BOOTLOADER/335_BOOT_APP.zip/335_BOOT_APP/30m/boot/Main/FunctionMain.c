//#############################################################################
/*<FH>*************************************************************************
* Copyright (c) :  2021-2031, Advancechip Co., Ltd. All Rights Reserved
* Original Author: pei.shen

* FileName: FunctionMain.c
* Current Version: V1.0
* Date: 21-Aug-2021

* ABSTRACT:  the function
* DESCRIPTION:

* Revise:
;   Last rev by:    ***
;   Last rev date:  ***
;   Last rev desc.: ***
**<FH>************************************************************************/

//-----------------------------------------------------------------------------
// Include

#include "MainInclude.h"

CPU_TIME_STRUCT   gCpuTime;

static void SelectMode_Boot(void);
static void JumpApp_DoAction(void);

void LED_blinky(void)
{
    int  tmp=0;
    gCpuTime.nLEDSumCnt ++;
    if(gCpuTime.nLEDSumCnt >= 250)
    {
       gCpuTime.nLEDSumCnt = 0;
       GpioDataRegs.GPATOGGLE.bit.GPIO24 = 1;
       tmp++;
       tmp++;
       GpioDataRegs.GPATOGGLE.bit.GPIO25 = 1;
       tmp++;
       tmp++;
       GpioDataRegs.GPATOGGLE.bit.GPIO27 = 1;
       tmp++;
       tmp++;
       GpioDataRegs.GPATOGGLE.bit.GPIO26 = 1;
    }
}


void SelectMode_Boot(void)
{
    if(gCpuTime.nBootMode == 0)    //SCI����
    {
        SCI_Boot();
    }else if(gCpuTime.nBootMode == 2)    //CAN����
    {

    }
    else{

    }
}


void Main05msFunction(void)
{
     SelectMode_Boot();
}


// ��Boot��ת��APPʵ�ַ���
// asm("    MOVL XAR7, #0x300000"); //0x300000��APP�������ڵ�ַ
// asm("    LB *XAR7");

void JumpApp_DoAction(void)
{
    //��nBootFlag == 0xAA ��ʾ�Ѿ���APP���򣬲���Ҫ����ֱ����APP��
    //����ʱ��ת�ڼ���յ���λ��������ָ��nBootFlag = 0,Boot��������������̡�

    gCpuTime.nBootFlag = *(Uint16 *)Boot_FlagAdd;

    if((gCpuTime.nBootFlag == 0xAA)&&(RemoteModbus.nAppJumpFlag == 1))
    {
        gCpuTime.nBootSumCnt++;

        if(gCpuTime.nBootSumCnt >= 2500)
        {
           gCpuTime.nBootSumCnt = 0;
           UpgradeJumpApp();
        }
    }
}


void Main2msFunction(void)
{
    LED_blinky();

    JumpApp_DoAction();
}

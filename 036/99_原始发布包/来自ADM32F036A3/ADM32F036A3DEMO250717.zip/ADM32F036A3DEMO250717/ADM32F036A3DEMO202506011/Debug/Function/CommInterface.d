# FIXED

Function/CommInterface.obj: ../Function/CommInterface.c
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/Define.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Device.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Adc.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_BootVars.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_DevEmu.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Cla.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Comp.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_CpuTimers.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_ECan.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_ECap.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_EPwm.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_EQep.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Gpio.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_I2c.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Lin.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_NmiIntrupt.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_PieCtrl.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_PieVect.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Spi.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Sci.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_SysCtrl.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_XIntrupt.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_PgaOpa.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/Main.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/Interface.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/MotorInclude.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/MainInclude.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/SubPrgInclude.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/RunSrc.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/LinLDF.h
Function/CommInterface.obj: C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/RemoteModbus.h

../Function/CommInterface.c:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/Define.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Device.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Adc.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_BootVars.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_DevEmu.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Cla.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Comp.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_CpuTimers.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_ECan.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_ECap.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_EPwm.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_EQep.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Gpio.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_I2c.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Lin.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_NmiIntrupt.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_PieCtrl.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_PieVect.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Spi.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_Sci.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_SysCtrl.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_XIntrupt.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/280xHeader/DSP2803x_PgaOpa.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/Main.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/Interface.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/MotorInclude.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/MainInclude.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/SubPrgInclude.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/RunSrc.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/LinLDF.h:

C:/Users/Allen1/Desktop/proj/ADM32F036A3DEMO250717/ADM32F036A3DEMO202506011/HeardFiles/SourceHeader/RemoteModbus.h:

